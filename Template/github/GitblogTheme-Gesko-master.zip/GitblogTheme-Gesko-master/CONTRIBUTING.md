# Become a contributor

> Huge disclaimer, this is my **first** website project, so of course there will be a lot of weirdnesses in the code. But this is OPEN SOURCE! 😍 Let's help each others

1. Fork
2. Create new branch, representing the changes
3. Make changes, ensure it's working
4. Push your own repo
5. Create PR, describe your changes
6. Thank You
