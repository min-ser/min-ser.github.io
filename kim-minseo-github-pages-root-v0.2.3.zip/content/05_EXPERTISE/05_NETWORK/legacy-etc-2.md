---
id: legacy-etc-2
type: expertise
title: 이해하면 인생이 바뀌는 TCP 송/수신 원리
enabled: true
sample: false
group: network
category: Network Fundamentals
createdDate: '2023-02-08'
updatedDate: '2023-02-08'
featured: false
summary: <iframe width="560" height="315" src="https://www.youtube.com/embed/K9L9YZhEjC0"
  title="이해하면 인생이 바뀌는 TCP 송/수신 원리" frameborder="0" allow="accelerometer
tags:
- Network Fundamentals
- Legacy Note
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

<iframe width="560" height="315" src="https://www.youtube.com/embed/K9L9YZhEjC0" title="이해하면 인생이 바뀌는 TCP 송/수신 원리" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

- http 통신 : 통신방식의 약속
- 통신방법
    - get   : 데이터 `조회` 요청  : Select
    - post  : 데이터 `추가` 요청  : Insert
    - put   : 데이터 `수정` 요청  : Update 
    - delete: 데이터 `삭제` 요청  : Delete

- 어떤 데이터에 대해 요청하는지? >> MIME
    Get : 요청 ? <요청할 데이터>
    Post: 요청

- [Statefull] 소켓통신[EX 채팅]
    - A PORT > write > server PORT
    - A PORT < READ  < server PORT
    ---
    - B PORT > write > server PORT
    - B PORT < READ  < server PORT
    ---
    - C PORT > write > server PORT
    - C PORT < READ  < server PORT
    - 단점 : server에 부하가 많음, 연결 지속


- [StateLess] http 통신
    - client > Get:write > server
    - client <  Read(응답 후 연결을 끊음) < server
    - 요청시마다 스트림을 연결해 데이터를 주고받는 방식 
    - 새로운 요청이 왔을 때 SC의 보안에 대해 이전 요청자가 맞는지에 대한 증명이 어려움 > Session 유지할 수 있는 방법이 없음
    - 원래 목적 : 문서전달의 목적
    
* Session : 데이터를 응답해줄 준비 > 인증이 되었음을 의미


- [MIME TYPE이란?](https://developer.mozilla.org/ko/docs/Web/HTTP/Basics_of_HTTP/MIME_types)
    - 어떻게 Body에 넣을 Data를 정의할것인지 >> MIME Type으로 정의
    - MINE

- Client > POST 요청 : ~Data를 추가해줘 > Server
    - POST 요청시 클라이언트는 Data를 어디에 담아서 보낼까?
    - 요청시
        - Header    : 
            - ex) Image/JPEG        
            - Data를 설명해주는 내용
            - 그외 다른 내용도 들어갈 수 있음
        - Body      : 
            - 실제 Data
            - ex) my.jpeg

- http 통신방식
    - 패킷 스위칭 : 
        - 데이터를 (`패킷`단위로) `쪼개서` 전송
        - 받는 입장에서 데이터를 `조립`해야함
        - 중간에 같은곳으로 데이터를 보내는곳이 있으면 데이터가 섞임
        - ![img]("/assets/category/ETC/04/21/01.PNG")

    - 서킷 스위칭 : 
        - 데이터를 한번에 싣고 전송
        - 속도가 빠름
        - 물리적으로 선이 연결되어야함 > 비용증가