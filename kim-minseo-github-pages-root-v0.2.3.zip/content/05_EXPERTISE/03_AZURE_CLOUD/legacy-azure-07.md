---
id: legacy-azure-07
type: expertise
title: '[Azure] SUSE Linux Enterprise Server Pacemaker 설정 [전체]'
enabled: true
sample: false
group: azure-cloud
category: Azure Cloud
createdDate: '2023-03-03'
updatedDate: '2023-03-03'
featured: false
summary: PaceMaker 목차 1. 인프라 구성 1. 아키텍처 설계 2. 리소스 생성 2. Azure 역할 할당 설정 1. 관리 ID 사용
  1. 사용자 지정 역할 추가 2. Azure 역할 할당 2. ~~서비스 주체 사용~~ 3. pacemaker 설치 1. 운영체제 구성 2
tags:
- Azure
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# PaceMaker

---
## 목차
1. 인프라 구성
    1. 아키텍처 설계
    2. 리소스 생성

2. Azure 역할 할당 설정
    1. 관리 ID 사용
        1. 사용자 지정 역할 추가
        2. Azure 역할 할당
    2. ~~서비스 주체 사용~~

3. pacemaker 설치
    1. 운영체제 구성
    2. cloud-netconfig-azure 구성
    3. Keygen 작업
    4. host 등록
    5. 클러스터 설치

4. 펜싱 디바이스 생성
    1. ~~SDB 디바이스 사용하는 경우~~
    2. Azure 펜스 에이전트 사용하는 경우

5. Pacemaker 구성

---
---

# [1]. 인프라 구성

1. 전체 아키텍처 구성
![SAP 아키텍처 설계](/assets/category/Azure/2023/03/06/Ver2.png)
    1. Resource Group 생성 : PoCShowRoom
    2. Virtual Network 생성

    네트워크 명 | 네트워크 주소
    ---------- | ------------
    MGMT            | 10.0.0.0/16
    SAP-vn          | 10.1.0.0/16
    AP_1            | 10.1.1.0/24
    AP_2            | 10.1.2.0/24
    DB_1            | 10.1.3.0/24
    DB_2            | 10.1.4.0/24

3. 리소스 생성
    1. AP Server Resource 구성
    ![img](/assets/category/Azure/2023/02/27/AP1-01.PNG)
    ```
        EX) AP #1 가상머신 구성
    ```
    * [TEST 계정]
        - id : demouser
        - pw : demo!pass123

    가상머신이름 | 설정  | 선택
    ----------- | ---- | ----
    ALL | OS | 배포판 : SUSE Enterprise Linux for SAP 15 SP1 +24x7 Support - 2Gen
    ALL | OS image | ![img](/assets/category/Azure/2023/02/27/AP1-02.PNG)
    AP-1, DB-1 | 가용성 영역 | **Zone 1**
    AP-2, DB-2 | 가용성 영역 | **Zone 3**
    AP-1 | 네트워크 주소 | AP_1 10.1.1.0/24
    AP-2 | 네트워크 주소 | AP_2 10.1.2.0/24
    DB-1 | 네트워크 주소 | DB_1 10.1.3.0/24
    DB-2 | 네트워크 주소 | DB_2 10.1.4.0/24

# [2]. Azure 역할 할당 설정

```
VM이 뻗었을 경우 원활한 Cluster를 위해 각 VM에 권한을 지정해주어야 한다.
그러기 위해 관리 ID를 사용하거나 서비스 주체 방식으로 권한을 생성해서
VM에 역할을 할당한다.
```

1. 관리 ID 사용 [해당 방식으로 진행]
    * **사용자 지정 역할 추가**
    1. 구독 > 액세스 제어(IAM) 클릭
    ![관리 ID](/assets/category/Azure/2023/03/03/01.PNG)
    2. 추가를 클릭하여 **사용자 지정 역할 추가** 클릭
    ![관리 ID](/assets/category/Azure/2023/03/03/02.PNG)
    3. 기본탭에서 **사용자 지정 역할 이름** 입력, 기준 권한에서 JSON에서 시작 선택
    ![관리 ID](/assets/category/Azure/2023/03/03/03.PNG)
    4. JSON탭에서 편집버튼을 클릭해서 편집모드로 설정
    ![관리 ID](/assets/category/Azure/2023/03/03/04.PNG)
    5. 구독 아이디만 변경하여 아래 JSON 내용 복사 붙여넣기 후 저장 후 생성과정 진행
    ```
    {
        "properties": {
            "roleName": "자동생성됨",
            "Name": "Linux fence agent Role",
            "description": "Allows to power-off and start virtual machines",
            "description": "",
            "assignableScopes": [
                "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
            ],
            "permissions": [
                {
                    "actions": ["Microsoft.Compute/*/read",
                            "Microsoft.Compute/virtualMachines/powerOff/action",
                            "Microsoft.Compute/virtualMachines/start/action"],
                    "notActions": [],
                    "dataActions": [],
                    "notDataActions": []
                }
            ]
        }
    }
    ```
    ![관리 ID](/assets/category/Azure/2023/03/03/05.PNG)

    * Azure 역할 할당
    1. 역할을 할당해줄 VM에 접속 > ID클릭
    ![관리 ID](/assets/category/Azure/2023/03/03/06.PNG)
    2. 시스템 할당 항목에서 상태 켜기로 변경 후 저장
    ![관리 ID](/assets/category/Azure/2023/03/03/07.PNG)
    3. 사용 권한이 나타나면 **Azure 역할 할당**을 클릭해준다.
    ![관리 ID](/assets/category/Azure/2023/03/03/08.PNG)
    4. **역할 할당 추가(미리 보기)** 클릭, 아래 내용 입력 후 저장
        - 범위 : 구독
        - 구독 : 진행중인 구독으로 선택
        - 역할 : 위에서 생성한 역할 이름 선택
    ![관리 ID](/assets/category/Azure/2023/03/03/09.PNG)
    5. 이와 같은 과정을 AP-1,2 DB-1,2 총 4개의 VM에 적용
    ![관리 ID](/assets/category/Azure/2023/03/03/10.PNG)
2. ~~서비스 주체 사용~~

# [3]. pacemaker 설치

1. 운영 체제 구성
```
    Pacemaker는 경우에 따라 허용된 수를 모두 사용할 수 있는 많은 프로세스를 만듭니다.    
    이 경우 클러스터 노드 간의 하트비트가 실패하고 리소스의 장애 조치(failover)가 발생할 수 있습니다.    
    다음 매개 변수를 설정하여 허용되는 "최대 프로세스 수"를 늘리는 것이 좋습니다.
```
    1. vi 편집기를 이용해 configuration file 설정
    ```
    sudo vi /etc/systemd/system.conf
    ```

    2. Change the DefaultTasksMax
    ```
    #DefaultTasksMax=512
    DefaultTasksMax=4096
    ```
    ![운영 체제 구성](/assets/category/Azure/2023/03/03/11.png)

    3. Activate this setting
    ```
    sudo systemctl daemon-reload
    ```

    4. Test to ensure that the change was successful
    ```
    sudo systemctl --no-pager show | grep DefaultTasksMax
    ```
    ![img](/assets/category/Azure/2023/02/28/06.PNG)

    5. 더티 캐시의 크기를 줄입니다. [vi 편집기 이용]
    ```
    sudo vi /etc/sysctl.conf
    ```
    ```
    # Change/set the following settings
    vm.dirty_bytes = 629145600
    vm.dirty_background_bytes = 314572800
    ```
    ![img](/assets/category/Azure/2023/02/28/07.PNG)

    6. 스왑 사용량을 줄이고 메모리를 선호하려면    
    vm.swapiness가 10으로 설정되어 있는지 확인합니다.
    ```
    # Change/set the following setting
    vm.swappiness = 10
    ```
    ![img](/assets/category/Azure/2023/02/28/08.PNG)

    ```
    # Change/set the following settings
    vm.dirty_bytes = 629145600
    vm.dirty_background_bytes = 314572800
    # Change/set the following setting
    vm.swappiness = 10
    ```

2. cloud-netconfig-azure 구성
```
    클라우드 네트워크 플러그 인이 가상 IP 주소를 제거하는 것을 방지하려면    
    Pacemaker가 할당을 제어해야 하므로   
    다음 코드와 같이 네트워크 인터페이스에 대한 구성 파일을 변경합니다.
```
    1. Edit the configuration file
    ```
    sudo vi /etc/sysconfig/network/ifcfg-eth0 
    ```
    ![img](/assets/category/Azure/2023/02/28/09.PNG)

    2. CLOUD_NETCONFIG_MANAGE 부분을 no로 수정
    ![img](/assets/category/Azure/2023/02/28/10.PNG)

3. Keygen 작업

    No | Keygen
    -- |-----------------
    1 | NO1 SERVER keygen 생성 
    2 | NO1 copy the public key 확인
    3 | NO2 > NO1 SERVER의 **authorized_keys**에 복사
    4 | NO2 SERVER keygen 생성
    5 | NO1 > NO2 SERVER의 **authorized_keys**에 복사
    6 | NO1 copy the public key 확인
    7 | 노드간 키 교환 상태 테스트 SSH 진행
    
    1.  NO1 SERVER keygen 생성
    ```
    sudo ssh-keygen
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/12.PNG)
    2. NO1 다음 명령어 실행 후 public key 복사
    ```
    sudo cat /root/.ssh/id_rsa.pub
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/13.PNG)

    3. NO2 > NO1 SERVER의 **authorized_keys**에 복사
    ```
    sudo vi /root/.ssh/authorized_keys  
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/14.PNG)

    4. NO2 SERVER keygen 생성
    ```
    sudo ssh-keygen
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/15.PNG)

    5. NO2 copy the public key 확인 
    ```
    sudo cat /root/.ssh/id_rsa.pub
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/16.PNG)

    6. NO2 > NO1 SERVER의 **authorized_keys**에 복사
    ```
    sudo vi /root/.ssh/authorized_keys  
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/17.PNG)

    7. NO1 SERVER서버에서 NO2 SSH접근 테스트
    ```
    ssh <node2서버 계정>@<node2서버 ip> 
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/18.PNG)

    8. NO2 SERVER서버에서 NO1 SSH접근 테스트
    ```
    ssh <node1서버 계정>@<node1서버 ip> 
    ```
    ![Keygen](/assets/category/Azure/2023/03/03/19.PNG)

    * ip 확인 명령어 
    ```
    ip address
    ```

4. host 등록

    1. 필요한 패키지 및 모듈 설치작업
    ```
    Azure에서 제공되는 SUSE리눅스로 작업시 이미 설치된 내용이므로 SKIP
    ```
        1. Azure 펜스 에이전트를 기반으로 fence-agents 패키지를 설치
        ```
        sudo zypper install fence-agents
        ```

        2. Azure Python SDK 및 Azure Identity Python 모듈을 설치
        공식문서는 버전 15.1로 되어있으나 실제 버전(15.3)과 동일한 버전으로 설치해야함
        ```
        # You might need to activate the public cloud extension first. In this example, the SUSEConnect command is for SLES 15 SP1
        SUSEConnect -p sle-module-public-cloud/15.3/x86_64
        sudo zypper install python3-azure-mgmt-compute
        sudo zypper install python3-azure-identity
        ```

    2. [NO1, NO2] host name 설정
    > 실제 구성시 등록할 VM의 수 만큼 등록해야함
    > 각 노드의 수 만큼 IP정보와 지정할 도메인(hostname) 이름 등록

        ```
        # IP address of the first cluster node
        <NO1 서버의 Private PI> <hostname 또는 지정할 노드 도메인 이름>
        # IP address of the second cluster node
        <NO2 서버의 Private PI> <hostname 또는 지정할 노드 도메인 이름>
        ```
        
        1. 각 노드의 ip와 hostname 확인
        ```
        ip address
        hostname
        ```
        ![host 등록](/assets/category/Azure/2023/03/03/20.PNG)

        2. host 등록
        ```
        sudo vi /etc/hosts
        ```
        * NO-1 Server
        ![host 등록](/assets/category/Azure/2023/03/03/21.PNG)
        * NO-2 Server
        ![host 등록](/assets/category/Azure/2023/03/03/22.PNG)

        3. 등록한 도메인 이름으로 ping test
        ```
        ping <등록도메인 이름>
        ```
        * NO1 SERVER에서 NO2 SERVER로 ping 테스트
        ![host 등록](/assets/category/Azure/2023/03/03/23.PNG)
        * NO2 SERVER에서 NO1 SERVER로 ping 테스트
        ![host 등록](/assets/category/Azure/2023/03/03/24.PNG)


5. 클러스터를 설치
    ```
    # 클러스터 중지 명령어
    sudo crm cluster stop
    ```

    1. [NO1] SERVER에 클러스터 설치
    ```
    sudo crm cluster init
    ```
    ![클러스터 설치](/assets/category/Azure/2023/03/03/25.PNG)

    2. [NO2] SERVER에서 클러스터에 노드 추가
    ```
    sudo crm cluster join
    ```
    ![클러스터 조인](/assets/category/Azure/2023/03/03/26.PNG)

    3. hacluster 계정의 비밀번호 설정
    ```
    sudo passwd hacluster
    ```
        * NO1 SERVER
        ![no1](/assets/category/Azure/2023/03/03/27.PNG)
        * NO2 SERVER
        ![no2](/assets/category/Azure/2023/03/03/28.PNG)

    4. corosync 설정을 조정
    ```
    sudo vi /etc/corosync/corosync.conf
    ```
    * 아래 내용 추가
    ```
    token:          30000
    token_retransmits_before_loss_const: 10
    join:           60
    consensus:      36000
    max_messages:   20
    ```
        * NO1 SERVER
        ![no1](/assets/category/Azure/2023/03/03/29.PNG)
        * NO2 SERVER
        ![no2](/assets/category/Azure/2023/03/03/30.PNG)

    5. corosync 서비스 재시작
    ```
    sudo service corosync restart
    ```

    6. 웹 접속 후 로그인
        ```
        인바운트 포트 : 7630 등록 후 공용ip로 접근시
        아래 이미지와 같은 로그인 화면이 나온다면 성공

        id : hacluster
        pw : 지정한 비밀번호

        5-3번에서 지정한 비밀번호를 등록했다면
        로그인이 정상적으로 되는것을 확인할 수 있다.
        ```
    ![login](/assets/category/Azure/2023/03/03/31.PNG)

# [4]. 펜싱 디바이스 생성

1. ~~SDB 디바이스를 사용하는 경우~~
2. Azure 펜스 에이전트를 사용하는 경우

    ```
    sudo crm configure property stonith-enabled=true
    crm configure property concurrent-fencing=true
    ```
    * 필요정보
        1. VM이름
        2. 리소스 그룹
        3. 구독 아이디
        ![login](/assets/category/Azure/2023/03/03/32.PNG)
        4. host명
            * NO1 SERVER
            ![login](/assets/category/Azure/2023/03/03/33.PNG)
            * NO2 SERVER
            ![login](/assets/category/Azure/2023/03/03/34.PNG)
        5. 테넌트 아이디
            * Azure Active Directory > 개요
            ![login](/assets/category/Azure/2023/03/03/38.PNG)

    1. [NO1만 작업] 에이전트 **관리 ID**를 사용하려면 다음 명령어 실행
    
        ```
        # 해당 VM의 구독ID와 리소스 그룹명으로 변경
        # 클러스터 대상 노드의 host명:VM명 수정

        sudo crm configure primitive rsc_st_azure stonith:fence_azure_arm \
        params msi=true subscriptionId="<구독 ID>" resourceGroup="<리소스그룹 이름>" \
        pcmk_monitor_retries=4 pcmk_action_limit=3 power_timeout=240 pcmk_reboot_timeout=900 pcmk_host_map="<node1의 host 이름>:<node1의 VM이름>;<node2의 host 이름>:<node2의 VM이름>" \
        op monitor interval=3600 timeout=120

        sudo crm configure property stonith-timeout=900
        ```


        ![login](/assets/category/Azure/2023/03/03/35.PNG)
        ![login](/assets/category/Azure/2023/03/03/36.PNG)
        > 위 명령어가 성공적으로 동작시 웹에서 resource가 생성된다.
        ![login](/assets/category/Azure/2023/03/03/37.PNG)

    2. ~~서비스 주체 사용시 다음 명령어 실행~~

        ```
        # replace the bold strings with your subscription ID, resource group of the VM, tenant ID, service principal application ID and password

        sudo crm configure primitive rsc_st_azure stonith:fence_azure_arm \
        params subscriptionId="subscription ID" resourceGroup="resource group" tenantId="tenant ID" login="application ID" passwd="password" \
        pcmk_monitor_retries=4 pcmk_action_limit=3 power_timeout=240 pcmk_reboot_timeout=900 pcmk_host_map="prod-cl1-0:prod-cl1-0-vm-name;prod-cl1-1:prod-cl1-1-vm-name" \
        op monitor interval=3600 timeout=120

        sudo crm configure property stonith-timeout=900
    ```

# [5]. Pacemaker 구성

1. azure-events 에이전트에 대한 패키지정보 및 최신인지 확인
    ```
    sudo zypper info resource-agents
    ```
    * NO1 SERVER
        ![login](/assets/category/Azure/2023/03/03/39.PNG)
        
    * NO2 SERVER
        ![login](/assets/category/Azure/2023/03/03/40.PNG)

2. [NO1 SERVER] Pacemaker에서 리소스를 구성

    ```
    #Place the cluster in maintenance mode
    sudo crm configure property maintenance-mode=true

    #Create Pacemaker resources for the Azure agent
    sudo crm configure primitive rsc_azure-events ocf:heartbeat:azure-events op monitor interval=10s
    sudo crm configure clone cln_azure-events rsc_azure-events

    #Take the cluster out of maintenance mode
    sudo crm configure property maintenance-mode=false
    ```
    ![login](/assets/category/Azure/2023/03/03/41.PNG)

3. 웹에서 생성된 리소스 확인
    ![login](/assets/category/Azure/2023/03/03/42.PNG)