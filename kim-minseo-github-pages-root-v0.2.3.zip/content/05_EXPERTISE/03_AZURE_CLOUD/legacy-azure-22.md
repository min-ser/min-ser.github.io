---
id: legacy-azure-22
type: expertise
title: Azure APIM retry 정책 테스트
enabled: true
sample: false
group: azure-cloud
category: Azure APIM
createdDate: '2025-05-14'
updatedDate: '2025-05-14'
featured: false
summary: 1. Azure APIM 환경 구성 1. Create Resource Group 2. Create Virtual Network 3.
  Create Azure OpenAI 4. Create API Management 2. API Management와 Azure OpenAI
tags:
- Azure
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 1. Azure APIM 환경 구성
1. Create Resource Group
2. Create Virtual Network
3. Create Azure OpenAI
4. Create API Management

# 2. API Management와 Azure OpenAI간 연동
## 1. Named values 설정
Azure OpenAI의 액세스를 api-key로 인증하는 방법

1. Azure OpenAI의 Subscription Key 복사
2. Named values 등록

## 2. Backends 설정
1. Azure OpenAI의 Endpoint 복사
2. Backend의 Custom URL로 등록

# 3. API Management APIs등록
```xml
<!--
    - Policies are applied in the order they appear.
    - Position <base/> inside a section to inherit policies from the outer scope.
    - Comments within policies are not preserved.
-->
<!-- Add policies as children to the <inbound>, <outbound>, <backend>, and <on-error> elements -->
<policies>
    <inbound>
        <base />
        <!-- 'Test-Key' 필수 헤더 키 검증로직 -->
        <choose>
            <!-- <when condition="@( !context.Request.Headers.ContainsKey("TEST-KEY"))"> -->
            <when condition="@( !context.Request.Headers.ContainsKey("TEST-KEY") || context.Request.Headers.GetValueOrDefault("TEST-KEY","") != "test")">
                <return-response>
                    <set-status code="400" reason="Bad Request (KMS)" />
                    <set-header name="Content-Type" exists-action="override">
                        <value>application/json</value>
                    </set-header>
                    <set-body>{"error": "필수 헤더 누락 테스트. TEST-KEY값이 옳바르지 않거나 없음"}</set-body>
                </return-response>
            </when>
            <otherwise />
        </choose>

        <!-- Azure OpenAI BackEnd 연동-->
        <set-backend-service id="apim-generated-policy" backend-id="umla-mkc-oai-prd" />
        
        <!-- # Azure OpenAI Key 등록 - Azure OpenAI를 API방식 -->
        <set-header name="api-key" exists-action="override">
            <value>{{umla-mkc-oai-prd-key}}</value>
        </set-header>
        
        <!-- # Azure OpenAI 관리ID 적용
        <authentication-managed-identity resource="https://cognitiveservices.azure.com" />
        -->
        
        <!-- 
            PTU관련 접속 제한 설정
            renewal-period : 제한 시간 계산(초단위, 15 : 15초마다 카운터 초기화)
            calls : renewal-period동안 허용되는 최대 호출 횟수(3 : 3번 호출 허용)
            
            <rate-limit-by-key calls="3" renewal-period="15" counter-key="@(context.Subscription.Id)" />
            - calls="3" renewal-period="15" : 각 구독마다 별도로 15초에 3번 호출 허용
            - counter-key : 제한을 적용할 기준 키
                - Subscription.Id : 구독 id를 기준
                - GetValueOrDefault("Ocp-Apim-Subscription-Key","anonymous") : APIM 구독 키를 기준
                    - anonymous : 기본적으로 apim키가 없으면 접근불가(401)
                    - 예외 : Subscription key not required옵션 사용경우 apim키가 없어도 통과
        -->
        <rate-limit-by-key calls="3" renewal-period="15" counter-key="@(context.Request.Headers.GetValueOrDefault("Ocp-Apim-Subscription-Key","anonymous"))" />
    
    </inbound>
    <backend>
        <base />
    </backend>
    <outbound>
        <base />
    </outbound>
    <on-error>
        <base />
    </on-error>
</policies>
```

# 4. API Test
Request Body에 아래 예제를 복사하여 프롬프트를 입력한 후 "Send" 버튼을 클릭
```json
{
"messages": [
    {
    "role": "system",
    "content": [
        {
        "type": "text",
        "text": "You are an AI assistant that helps people find information."
        }
    ]
    },
    {
    "role": "user",
    "content": [
        {
        "type": "text",
        "text": "when Microsoft Windows was built?"
        }
    ]
    }
],
"temperature": 0.7,
"top_p": 0.95,
"max_tokens": 800
}
```

# Azure Policy 설정
## retry 정책 문
```xml
<retry
    condition="Boolean expression or literal"
    count="number of retry attempts"
    interval="retry interval in seconds"
    max-interval="maximum retry interval in seconds"
    delta="retry interval delta in seconds"
    first-fast-retry="boolean expression or literal">
        <!-- One or more child policies. No restrictions. -->
</retry>
```

## 특성
특성  | 설명  
------|-----  
condition | 부울입니다. 다시 시도를 중지할지(false) 또는 계속할지(true) 지정합니다. 정책 식이 허용됩니다.
count  | 시도할 다시 시도 횟수를 지정하는 1에서 50 사이의 양수입니다. 정책 식이 허용됩니다.
interval | 재시도 횟수 간에 대기 간격을 지정하는 양수(초)입니다. 정책 식이 허용됩니다.
max-interval | 재시도 횟수 간에 최대 대기 간격을 지정하는 양수(초)입니다. 지수 재시도 알고리즘을 구현하는 데 사용됩니다. 정책 식이 허용됩니다.
delta	| 대기 간격 증분을 지정하는 양수(초)입니다. 선형 및 지수 재시도 알고리즘을 구현하는 데 사용됩니다. 정책 식이 허용됩니다.
first-fast-retry | 부울입니다. true로 설정하면 첫 번째 다시 시도가 즉시 수행됩니다. 정책 식이 허용됩니다.

---
# Test Policy Statement


# 문서 참고
[API Management retry 정책](https://learn.microsoft.com/ko-kr/azure/api-management/retry-policy)
