---
id: legacy-azure-05
type: expertise
title: '[Azure] VMSS 서버 배포'
enabled: true
sample: false
group: azure-cloud
category: Azure Cloud
createdDate: '2023-02-02'
updatedDate: '2023-02-02'
featured: false
summary: VMSS 배포 VMSS 환경 구성 VMSS 생성하면서 LB 추가 VMSS 네트워킹 인바운드 포트 규칙 추가 해당 부분에서 추가된 규칙은
  인스턴스 전체 규칙 으로 등록됨 외부에서 접근하기위한 포트 추가 HTTPS HTTP 사용중인 서버 포트 ex 아파치톰켓 서버 포트 i
tags:
- Azure
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# VMSS 배포

## VMSS 환경 구성
* VMSS 생성하면서 LB 추가
- VMSS 
    - 네트워킹 > 인바운드 포트 규칙 추가
        > 해당 부분에서 추가된 규칙은 `인스턴스 전체 규칙`으로 등록됨   
        > 외부에서 접근하기위한 포트 추가
        - HTTPS
        - HTTP
        - 사용중인 서버 포트 ex)아파치톰켓 서버 포트
        ![img](/assets/category/Azure/2023/02/02/vmss-01.PNG)

- 로드벨런서 설정
    > ![img](/assets/category/Azure/2023/02/02/lb-01.PNG)
    > 1. 부하 분산 규칙 : 백 엔드 포트를 해당 인스턴스에서 올린 포트와 일치   
    > 2. 상태프로브 : 해당 포트는 `백 엔드 포트`를 의미    
    > 3. `인바운드 NAT 규칙` : ssh 통신시 필요한 ip와 포트정보 참고    

- 1. 백 엔드 풀 > `부하 분산 규칙`
    - 등록된 백 엔드 풀 클릭
    > ![img](/assets/category/Azure/2023/02/02/lb-02.PNG)
    - LBRule 클릭(자동등록된 부하분산 규칙)
    > ![img](/assets/category/Azure/2023/02/02/lb-03.PNG)
    - 백 엔드 포트 설정
    > 서비스 하는 서버 포트 등록    
    > EX)톰켓 아파치서버의 포트
    ![img](/assets/category/Azure/2023/02/02/lb-04.PNG)

- 2. 상태프로브 설정
- 3. 인바운드 NAT 규칙 설정
    
---
## 아파치톰켓 설치 과정
1. 리눅스 환경 구성
    - Azure VM 생성
    - 인바운드 보안 규칙 추가
    ![img](/assets/category/java/2023/02/02-01.PNG)
        - 아파치에서 설정한 내부 포트 지정(8080)

---

2. 자바 설치
```
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install openjdk-8-jre
```

---

3. 서버설치
    - 아파치 톰켓파일 리눅스용 FTP로 전송
    - 압축풀기 :` tar -xvf [파일명]`

---

4. bin 파일에 서버 start.sh 경로로 이동 후 서버 실행
```
~/apache-tomcat-8.5.82/bin$ sh start.sh
```

---

5. VM Public IP를 통해 서버 접근
![img](/assets/category/java/2023/02/02-02.PNG)

---

6. 이중화 구성
- 아래 디렉토리로 접근 후 index.jsp를 수정하여 서버 구분
- /apache-tomcat-8.5.82/webapps/ROOT/index.jsp

---



