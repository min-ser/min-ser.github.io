---
id: legacy-devops-04
type: expertise
title: Jenkins CI/CD 원격서버(Docker) SpringBoot 배포
enabled: true
sample: false
group: devops-automation
category: DevOps
createdDate: '2024-07-08'
updatedDate: '2024-07-08'
featured: false
summary: 목차 1. Infra 환경 구성 2. SpringBoot Project Local Test https://min ser.github.io/writing/DevOps
  03/ 3. Remote Server 구성 https://min ser.github.io/writing/
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 목차
1. Infra 환경 구성
2. [SpringBoot Project Local Test](https://min-ser.github.io/writing/DevOps-03/)
3. [Remote Server 구성](https://min-ser.github.io/writing/DevOps-03/)
4. Jenkins Remote Server 등록
5. [Jenkins Repository 연동](https://min-ser.github.io/writing/DevOps-03/)
6. Jenkins 배포 Pipeline 구성
7. Jenkins Build
8. SpringBoot 서버 종료

---
<br><br><br>

# 1. Infra 환경구성
![img](/assets/category/DevOps/03/00.png)
1. SVN Server 1대
2. Jenkins Server 1대
3. WAS Server(Remote Server) 1대

--- 
<br><br><br>

# 2. [SpringBoot Project Local Test](https://iiblackcode.github.io/writing/DevOps-03/)

---
<br><br><br>

# 3. Remote Server 구성

배포 대상서버의 환경을 설정해준다.

## 1. 개발환경 비교
- SpringBoot 3.4
- JDK 17
- Gradle

## 2. 원격서버 설정
```shell
sudo apt update
sudo apt install openjdk-17-jdk -y
sudo apt install maven -y
sudo apt install gradle
``` 

---
<br><br><br>

# 4. Jenkins Remote Server 등록

## 1. Publish Over SSH Plugin 설치
### 1). Dashboard > Jenkins 관리로 이동 후 Plugins를 클릭한다.

![img](/assets/category/DevOps/04/1-1.png)

### 2). Available plugins를 선택하고 `Publish over ssh`를 검색하여 설치한다.

![img](/assets/category/DevOps/04/1-2.png)

### 3). 설치가 끝나고 실행중인 작업이 없으면 Jenkins를 재시작한다.

![img](/assets/category/DevOps/04/1-2.png)

## 2. 배포대상 원격서버 등록
아래 이미지와 같이 SSH Server를 등록하지 않은 경우 ssh서버등록을 해야한다.
![img](/assets/category/DevOps/04/ssh_server_00.png)

### 1). Dashboard > Jenkins 관리 > System(시스템 설정)메뉴로 진입
![img](/assets/category/DevOps/04/ssh_server_01.png)

### 2). SSH Servers에서 추가를 눌러 SSH Server를 추가
![img](/assets/category/DevOps/04/ssh_server_02.png)

### 3). 다음과 같이 배포대상 VM정보를 입력하여 추가
![img](/assets/category/DevOps/04/ssh_server_03.png)
- Name : 서버를 구분하기 위한 명칭
- Hostname : 서버 주소
- Username : 배포자명
- `Remote Directory` : 배포 원격 디렉토리[중요]
    - 원격 디렉토리에서 배포할 경로를 설정해준다.
    - home/master/was/SpringBoot

### 4). 고급을 눌러 설정한 VM환경에 맞게 세팅해준다.

나같은 경우 Azure VM에 ID/Password방식으로 구성했기 때문에 `Passphrase / Password`에서 해당 VM의 비밀번호만 넣어주면 된다. 토큰 인증방식으로 구성한  경우 별도의 인증키를 넣어주어야 한다.
![img](/assets/category/DevOps/04/ssh_server_04.png)

### 5). 위 사항을 정확히 입력 후 Test Configuration을 클릭하면 왼쪽에 `Success`라고   뜬다. 확인 후 저장을 누른다.
![img](/assets/category/DevOps/04/ssh_server_05.png)

---
<br><br><br>

# 5. [Jenkins Repository 연동](https://iiblackcode.github.io/writing/DevOps-03/)
아래 링크를 참고해서 Repository와 Jenkins연동작업 진행
- URL : https://iiblackcode.github.io/writing/DevOps-03/

---
<br><br><br>

# 6. Jenkins 배포 Pipeline 구성
## 1. Dashboard 에서 작업할 job을 선택합니다.
![img](/assets/category/DevOps/04/2-1.png)
> 본 설명에서 Springboot-Demo-war 선택

## 2. 구성을 선택합니다.
![img](/assets/category/DevOps/04/2-2.png)

## 3. Build Steps 구성

build를 하기위한 방식은 여러방식이 있는듯 하다. 각자 환경에 맞게 선택하면 된다.
### 1). script 명령어를 통해 build
    
```shell
# gradlew 파일의 위치로 이동
cd demo-war

ls -l

chmod +x gradlew
./gradlew clean build --info
```

![img](/assets/category/DevOps/04/build_01.png)

### 2). [작성 예정]

## 4. 빌드 후 조치

`빌드 후 조치 추가` > `Send build artifacts over SSH` 선택
![img](/assets/category/DevOps/04/build-after_01.png)
    
### SSH Server
- Name : 등록한 원격 서버를 선택한다.
- `고급`을 눌러 `Verbose output in console`에 체크해준다.

    배포단계에서 상세로그를 확인할 수 있다. 

    ![img](/assets/category/DevOps/04/build-after_02.png)

### Transfers
- Source files : 
    - <프로젝트명>/<파일경로>/<.war or .jar> 파일형식으로 build된 파일경로를 입력한다.
    - 파일이 한개인 경우 **/*.war 와 같은 형식으로 입력하면 된다. 
    - SpringBoot build시 plain을 생성하게 되므로 확인필요.
- Remove prefix : 
    - <프로젝트명>/<파일경로>/
    - 비워두면 쓸대없는 디렉토리가 생성된다고 한다. (직접 해보진 않음)
- Remote directory : 
    - 원격 서버에서 배포할 디렉토리를 입력한다.
    - 단, 경로가 맞지않으면 자동으로 생성하지 않아 실패하게됨 
- Exec command : 
    - war나 jar파일을 원격서버로 전달하고 해당 경로에서 진행할 작업 script를 작성한다.
    - 바로 서버를 구동하기 위해 아래와 같이 명령어를 넣어주었다.
        ```shell
        java -jar -Dserver.port=6060 demo-war-0.0.1-SNAPSHOT.war
        ```
        이렇게 명령어를 작성하는 경우 Build가 끝나지 않으므로 구동 후 빠져나오는 옵션설정을 해줘야 한다.

###  작성 참고
![img](/assets/category/DevOps/04/build_02.png)
작성 완료 후 저장버튼을 눌러 저장을 완료한다.

---
<br><br><br>

# 7. Jenkins Build
## 1. 지금 빌드를 눌러 빌드를 진행하면 아래에 Build History가 새로 나와 빌드가 진행된다.
![img](/assets/category/DevOps/04/build-test_01.png)

## 2. 빌드번호를 클릭해서 Console Output을 통해 진행중인 로그도 확인이 가능하다.
![img](/assets/category/DevOps/04/build-test_02.png)

## 3. build 완료 후 원격서버 Airtifact 등록 확인

Build가 완료되면 원격서버에서 서버실행 명령어까지 진행하면서 ssh server등록시 remote directory에 입력했던 Artifact등록 디렉토리에 war/jar가 생성된다.

![img](/assets/category/DevOps/04/build-test_03.png)

### 4). Sample Spring Boot Project가 배포됨[완료]
![img](/assets/category/DevOps/04/build-test_04.png)

---
<br><br><br>

# 8. SpringBoot 서버 종료
## 1. 원격 서버에 접속 후 pid 확인
```shell
# 명령어
ps -ef | grep jar

# 명령어 실행 예시
master@master:~$ ps -ef | grep jar
master     53909       1  0 05:09 ?        00:00:26 java -jar -Dserver.port=6060 demo-war-0.0.1-SNAPSHOT.war
master     82641   58358  0 07:03 pts/0    00:00:00 grep --color=auto jar
```

## 2. 해당 pid 종료
```shell
# 명령어
sudo kill -9 종료시킬 PID 번호

# 명령어 실행 예시
master@master:~$ sudo kill -9 53909
```

## 3. 다시 pid 확인
```shell
master@master:~$ ps -ef | grep jar
master     83534   58358  0 07:07 pts/0    00:00:00 grep --color=auto jar
```
