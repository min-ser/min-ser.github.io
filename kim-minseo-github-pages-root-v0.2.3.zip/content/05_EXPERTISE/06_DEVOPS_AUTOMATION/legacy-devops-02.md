---
id: legacy-devops-02
type: expertise
title: Jenkins 설치
enabled: true
sample: false
group: devops-automation
category: DevOps
createdDate: '2024-06-20'
updatedDate: '2024-06-20'
featured: false
summary: 1. Jenkins 설치 1 . Jenkins 저장소 추가 2 . Jenkins 설치 2. Jenkins 시작 및 설정 1 . Jenkins
  서비스 시작 2 . Jenkins 서비스 상태 확인 1~2 . 다음과 같은 에러 발생 jdk 설치가 되지않아 발생했던 에러 jd
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 1. Jenkins 설치
## [1]. Jenkins 저장소 추가
```shell
# 패키지 목록 업데이트
sudo apt-get update

# jdk 없으면 설치
sudo apt-get install openjdk-11-jdk

wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
```

## [2]. Jenkins 설치
```shell
sudo apt-get install jenkins
```

# 2. Jenkins 시작 및 설정
## [1]. Jenkins 서비스 시작
```shell
sudo systemctl start jenkins
```

## [2]. Jenkins 서비스 상태 확인
```shell
sudo systemctl status jenkins
```

## [1~2]. 다음과 같은 에러 발생
```shell
cody@svn:~$ sudo systemctl start jenkins
Job for jenkins.service failed because the control process exited with error code.
See "systemctl status jenkins.service" and "journalctl -xe" for details.
cody@svn:~$ sudo systemctl status jenkins
● jenkins.service - Jenkins Continuous Integration Server
     Loaded: loaded (/lib/systemd/system/jenkins.service; enabled; vendor preset: enabled)
     Active: failed (Result: exit-code) since Thu 2024-06-20 01:48:40 UTC; 13s ago
    Process: 14788 ExecStart=/usr/bin/jenkins (code=exited, status=1/FAILURE)
   Main PID: 14788 (code=exited, status=1/FAILURE)

Jun 20 01:48:40 svn systemd[1]: jenkins.service: Scheduled restart job, restart counter is at 5.
Jun 20 01:48:40 svn systemd[1]: Stopped Jenkins Continuous Integration Server.
Jun 20 01:48:40 svn systemd[1]: jenkins.service: Start request repeated too quickly.
Jun 20 01:48:40 svn systemd[1]: jenkins.service: Failed with result 'exit-code'.
Jun 20 01:48:40 svn systemd[1]: Failed to start Jenkins Continuous Integration Server.
```

> jdk 설치가 되지않아 발생했던 에러
> jdk 설치과정 추가-2024-06-20

## [3]. Jenkins 초기 비밀번호 확인
Jenkins를 처음 설치하고 실행할 때는 초기 비밀번호를 사용하여 설정해야 합니다. 초기 비밀번호는 /var/lib/jenkins/secrets/initialAdminPassword 파일에 저장되어 있습니다.
```shell
sudo cat /var/lib/jenkins/secrets/initialAdminPassword

# 실행시 아래와 같이 비밀번호 확인가능
cody@svn:~$ sudo cat /var/lib/jenkins/secrets/initialAdminPassword
30c97aab16254252a318381a2e2a0055
```

## [4]. 4. Jenkins 웹 인터페이스 접근
```shell
http://your_server_ip_or_domain:8080

# 로컬 curl 테스트
cody@svn:~$ curl 127.0.0.1:8080
<html>
<head>
<meta http-equiv='refresh' content='1;url=/login?from=%2F'/>
<script id='redirect' data-redirect-url='/login?from=%2F' src='/static/a43e35a2/scripts/redirect.js'>
</script>
</head>
<body style='background-color:white; color:white;'>
Authentication required
<!--
-->
</body></html>
```

그리고 앞서 확인한 초기 비밀번호(30c97aab16254252a318381a2e2a0055)를 입력합니다.

![image](/assets/category/DevOps/Jenkins/01.png)


## [5]. 플러그인 설치 및 관리자 사용자 생성
초기 비밀번호를 입력한 후 플러그인 설치 및 관리자 사용자 생성을 진행합니다. 기본 추천 플러그인 설치를 선택하면 일반적으로 필요한 플러그인들이 자동으로 설치됩니다.

1. ![image](/assets/category/DevOps/Jenkins/02.png)
>추천 플러그인 선택

2. ![image](/assets/category/DevOps/Jenkins/03.png)
>설치 진행중

3. ![image](/assets/category/DevOps/Jenkins/04.png)
>계정 생성 후 `Save and Continue`

4. ![image](/assets/category/DevOps/Jenkins/05.png)
>인스턴스 구성 `Save and Finish`

5. ![image](/assets/category/DevOps/Jenkins/06.png)
>인스턴스 구성 `Start using Jenkins`

    Jenkins URL은 다양한 Jenkins 리소스에 대한 절대 링크의 루트 URL을 제공하는 데 사용됩니다. 즉, 이메일 알림, PR 상태 업데이트, BUILD_URL빌드 단계에 제공되는 환경 변수를 포함한 많은 Jenkins 기능이 올바르게 작동하려면 이 값이 필요합니다.
    표시된 제안된 기본값은 아직 저장되지 않았 으며 가능한 경우 현재 요청에서 생성됩니다. 가장 좋은 방법은 이 값을 사용자가 사용할 것으로 예상되는 URL로 설정하는 것입니다. 이렇게 하면 링크를 공유하거나 볼 때 혼란을 피할 수 있습니다.

6. ![image](/assets/category/DevOps/Jenkins/07.png)
>완료

# 3. 프로젝트 설정
## [1]. 새 프로젝트 생성
1. Jenkins 대시보드에서 "새로운 아이템"을 클릭합니다.
    ![image](/assets/category/DevOps/Jenkins/08.png)

2. 프로젝트 이름을 입력하고, "Freestyle 프로젝트"를 선택한 후 "확인"을 클릭합니다.
    ![image](/assets/category/DevOps/Jenkins/09.png)



## [2]. 소스 코드 관리 설정
1. 프로젝트 설정 페이지에서 "소스 코드 관리" 섹션으로 이동합니다.
    ![image](/assets/category/DevOps/Jenkins/10.png)
2. 여기서 사용할 소스 코드 관리 시스템을 선택합니다(Git, Subversion 등).
    ![image](/assets/category/DevOps/Jenkins/11.png)
    1. 예시: Git
        Repository URL: Git 리포지토리 URL을 입력합니다.
        Credentials: 필요한 경우 인증 정보를 추가합니다.
    2. SVN 연동시
       1. Dashboard > Jenkins 관리 > Plugins 이동
          1. ![image](/assets/category/DevOps/Jenkins/12.png)
          2. ![image](/assets/category/DevOps/Jenkins/13.png)
       2. Available plugins에서 Subversion 검색
          1. ![image](/assets/category/DevOps/Jenkins/14.png)
          2. ![image](/assets/category/DevOps/Jenkins/15.png)
       3. Subversion Plugin 설치 후 Configure 화면
          - ![image](/assets/category/DevOps/Jenkins/16.png)
3. SVN repository 연동작업을 진행합니다.
 
## [3]. 빌드 트리거 설정
"Build Triggers" 섹션으로 이동하여 빌드 트리거를 설정합니다. 예를 들어, 코드가 커밋될 때마다 빌드를 트리거하려면 "Poll SCM"을 선택하고 스케줄을 입력합니다.

## [4]. 빌드 설정
"Build" 섹션으로 이동하여 빌드 단계를 추가합니다. 예를 들어, 쉘 스크립트를 실행하려면 "Execute shell"을 선택하고 빌드 스크립트를 입력합니다.

- 예시
```
#!/bin/bash
echo "Building the project..."
# 여기에 실제 빌드 명령어를 추가합니다.
```

## [5]. 빌드 후 작업 설정
"Post-build Actions" 섹션으로 이동하여 빌드 후 작업을 추가합니다. 예를 들어, 빌드 결과를 이메일로 보내려면 "E-mail Notification"을 설정할 수 있습니다.

# 4. Jenkins 빌드 실행
프로젝트 설정을 마친 후 "저장"을 클릭합니다. 그리고 대시보드에서 방금 생성한 프로젝트를 선택하고 "Build Now"를 클릭하여 빌드를 실행합니다.

빌드 진행 상황과 결과는 Jenkins 대시보드에서 실시간으로 확인할 수 있습니다.

위의 단계들을 통해 Jenkins 설치부터 기본 프로젝트 설정까지 완료할 수 있습니다. 프로젝트 설정 과정에서 필요에 따라 다양한 플러그인들을 추가하여 Jenkins의 기능을 확장할 수 있습니다.