---
id: legacy-docker-01
type: expertise
title: Docker를 이용한 SpringBoot 배포
enabled: true
sample: false
group: devops-automation
category: Docker
createdDate: '2023-10-26'
updatedDate: '2023-10-26'
featured: false
summary: Docker 명령어 해당 컨테이너 로그 확인 컨테이너 삭제 컨테이너 모두 삭제 이미지 삭제 이미지 모두 삭제 컨테이너 접속 1. SpringBoot
  war, jar파일 및 Dockerfile 준비 1. Spring Boot Dockerfile 설정 FROM JDK를 설
tags:
- Docker
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# Docker 명령어
## 해당 컨테이너 로그 확인
```bash
sudo docker logs --tail 20 -f <컨테이너 ID>
```
## 컨테이너 삭제
```bash
sudo docker rm <컨테이너 ID>
```
## 컨테이너 모두 삭제
```bash
sudo docker rm `docker ps -a -q`
```

## 이미지 삭제
```bash
sudo docker rmi <이미지ID>
```

## 이미지 모두 삭제
```bash
docker rmi `docker images -a -q`
```

## 컨테이너 접속
```bash
sudo docker attach <컨테이너 이름 or 아이디>
```

---

# 1. SpringBoot war, jar파일 및 Dockerfile 준비

## 1. Spring Boot Dockerfile 설정
- FROM - JDK를 설정합니다.
- ENV - 환경변수 설정를 설정합니다.
- WORKDIR - 환경변수를 경로로 지정합니다.
- COPY - 빌드된 jar 파일을 application.jar의 파일명으로 복사합니다.
- EXPOSE - 실행될 포트를 설정합니다.
- CMD - 명령어 옵션을 입력합니다.

## 1-1. jar 배포
```bash
FROM openjdk:11-jdk
# ENV APP_HOME=/usr/app/
WORKDIR $APP_HOME
COPY build/libs/*.jar application.jar
EXPOSE 8080
CMD ["java", "-jar", "application.jar"]
```
## 1-2. war 배포
```bash
FROM openjdk:11-jdk
# ENV APP_HOME=/usr/app/
WORKDIR $APP_HOME
COPY build/libs/*.war application.war
EXPOSE 8080
CMD ["java", "-jar", "application.war"]
```
## [참고] 배포 디렉토리 참고
- 디렉토리
![img](/assets/category/Docker/01-01.PNG)
- Dockerfile
```dockerfile
FROM openjdk:11-jdk
# ENV APP_HOME=/usr/app/
WORKDIR $APP_HOME
COPY /*.war application.war
EXPOSE 8080
CMD ["java", "-jar", "application.war"]
```

# 2. 도커 빌드(docker image 생성) 및 컨테이너 실행

## 1. Docker build
```bash
# build 명령어
sudo docker build -t <docker hub id>/<application name> .

# build 후 생성된 image 확인
sudo docker images
```
- 명령어 실습
![docker build images](/assets/category/Docker/01-02.PNG)

## 2. Docker Container run(image 사전 생성 필요)

![docker run 명령어](/assets/category/Docker/01-03.PNG)
- -p : 8080포트로 실행해서 9090포트로 포트포워딩(외부에서 9090 포트를 통해 접근)
- --name : container name 설정 : x-forwarded-for
- kbhc : tag값

- 명령어 실습
```bash
sudo docker run -d -p 9090:8080 --name springboot-container iiblackcode/kbhc
```
![docekr run](/assets/category/Docker/01-04.PNG)
![docekr ps -a](/assets/category/Docker/01-05.PNG)

## 컨테이너 ip 확인
![img](/assets/category/Docker/01-06.PNG)

---

# Docker hub로 image push
## 1. image생성을 위한 docker build
```bash
sudo docker build -t <docker hub id>/<application name>:<tag> .
```
![img](/assets/category/Docker/01-02.PNG)

## 2. docker login을 실행하여 docker hub에 가입했던 아이디와 비밀번호 입력
```bash
sudo docker login
```

## 3. docker hub로 이미지 push
```bash
sudo docker push <docker hub id>/<application name>
```
- [참고] 명령어
![img](/assets/category/Docker/01-07.PNG)

## 4. Docker hub 이미지 push 전
![img](/assets/category/Docker/01-08.PNG)

## 5. Docker hub 이미지 업로드 확인
![img](/assets/category/Docker/01-09.PNG)

- [tip] image 정보 변경이 필요한 경우
```bash
docker image tag <image id를 docker hub id로 변경><new application name>
```

---

# Docker hub로부터 image pull

## 1. Docker hub에 접속해서 이미지 pull 명령어 복사



## MEMO
```bash
az aks get-credentials --resource-group kn3-kbh-dev-ocareplus-hic-fr-rg --name kn3-kbh-dev-ocareplus-hic-fr-cl --admin

az acr login --name kbhchicdevacr33

VA60QOVFl+ag0NZzrw2D3nrACVdYWjgEXrOtwiZZPM+ACRD5GIsg
cYQEIsg4bIk73b9fupjDNHqmQXMOMVIrFTtO6Wm4Dc+ACRCEzloT

docker tag iiblackcode/xforwardedfor:kbhc kbhchicdevacr33.azurecr.io/iiblackcode/xforwardedfor:kbhc
docker push kbhchicdevacr33.azurecr.io/iiblackcode/xforwardedfor:kbhc
```