---
id: legacy-terraform-3
type: expertise
title: '[Terraform] 3. Azure Resource Group 생성'
enabled: true
sample: false
group: devops-automation
category: Terraform
createdDate: '2023-03-30'
updatedDate: '2023-03-30'
featured: false
summary: Terraform Workspace 설정 1. Terraform 파일 생성 아래 두 파일 생성 main.tf 하나로 합해도 무관 provider.tf
  main.tf <br <br 2. terraform init 아래 명령어를 통해 workspace의 환경을 terraf
tags:
- Terraform
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# Terraform Workspace 설정

## 1. Terraform 파일 생성
아래 두 파일 생성(main.tf 하나로 합해도 무관)

- provider.tf
```
provider "azurerm" {
    # Azure 고급기능 정의
    features{}

    # 인증정보를 등록할 경우 사용
    subscription_id = "<your-subscription-id>"
    client_id       = "<your-client-id>"
    client_secret   = "<your-client-secret>"
    tenant_id       = "<your-tenant-id>"
}
```

- main.tf
```
resource "azurerm_resource_group" "example" {
  name     = "example"
  location = "West Europe"
}
```
<br><br>


## 2. terraform init
- 아래 명령어를 통해 workspace의 환경을 terraform 환경으로 초기화 해준다.
- tf파일이 하나라도 있어야 해당 명령어가 작동함
- terraform 작업시 초기에 한번 선행되어야하는 명령어

```
terraform init
```

### 실행화면 참고


```
PS D:\GIT\PROJECT\Terraform\Test> terraform init

Initializing the backend...

Initializing provider plugins...
- Reusing previous version of hashicorp/azurerm from the dependency lock file
- Using previously-installed hashicorp/azurerm v3.50.0

Terraform has been successfully initialized!

You may now begin working with Terraform. Try running "terraform plan" to see
any changes that are required for your infrastructure. All Terraform commands
should now work.

If you ever set or change modules or backend configuration for Terraform,
rerun this command to reinitialize your working directory. If you forget, other
commands will detect it and remind you to do so if necessary.
```
<br><br>


## 3. terraform plan

Terraform에서 사용되는 명령어 중 하나로, 인프라스트럭처 코드 (Infrastructure as Code)의 변경 사항을 검토하고 미리보기를 제공하는 작업

```
terraform plan
```

### 실행화면 참고
```
PS D:\GIT\PROJECT\Terraform\Test> terraform plan

Terraform used the selected providers to generate the following execution plan.
Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # azurerm_resource_group.rg will be created
  + resource "azurerm_resource_group" "rg" {
      + id       = (known after apply)
      + location = "koreacentral"
      + name     = "test-rg"
    }

Plan: 1 to add, 0 to change, 0 to destroy.

─────────────────────────────────────────────────────────────────────────────────────── 

Note: You didn't use the -out option to save this plan, so Terraform can't guarantee to 
take exactly these actions if you run "terraform apply" now.
```
<br><br>


## 4. terraform apply -auto-approve
```
terraform apply --auto-approve
```

인프라스트럭처 코드 (Infrastructure as Code)를 실제 인프라스트럭처로 적용하는 작업
- -auto-approve 플래그는 Terraform이 apply 명령어를 실행할 때 모든 변경 사항을 자동으로 승인하도록 지시하는 옵션
- 즉, terraform apply -auto-approve 명령어를 실행하면 Terraform은 변경 사항을 검토한 후 인프라스트럭처를 업데이트하고, 변경 사항을 승인하지 않고 즉시 적용

### 실행화면 참고
```
PS D:\GIT\PROJECT\Terraform\Test> terraform apply --auto-approve

Terraform used the selected providers to generate the following execution plan.
Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # azurerm_resource_group.rg will be created
  + resource "azurerm_resource_group" "rg" {
      + id       = (known after apply)
      + location = "koreacentral"
      + name     = "test-rg"
    }

Plan: 1 to add, 0 to change, 0 to destroy.
azurerm_resource_group.rg: Creating...
azurerm_resource_group.rg: Creation complete after 2s [id=/subscriptions/ade73f1a-8f29-49ca-8e29-08e5a51bcd61/resourceGroups/test-rg]

Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

### test-rg의 리소스 그룹 생성 확인
![img](/assets/category/Terraform/2023/03/31/01.PNG)