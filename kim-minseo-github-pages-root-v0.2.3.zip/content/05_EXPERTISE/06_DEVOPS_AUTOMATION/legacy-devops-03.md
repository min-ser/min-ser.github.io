---
id: legacy-devops-03
type: expertise
title: SpringBoot SVN to Jenkins CICD 빌드 및 배포 [단일서버 배포]
enabled: true
sample: false
group: devops-automation
category: DevOps
createdDate: '2024-06-28'
updatedDate: '2024-06-28'
featured: false
summary: '목차 1. Infra환경 구성 2. SpringBoot Project Local Test 3. Remote Server 구성 4.
  Jenkins Repository 연동 5. Jenkins 배포 Pipeline 구성 6. Jenkins Build 7. 완료 1. 환경 '
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 목차
1. Infra환경 구성
2. `SpringBoot Project Local Test`
3. `Remote Server 구성`
4. `Jenkins Repository 연동`
5. Jenkins 배포 Pipeline 구성
6. Jenkins Build
7. 완료

# 1. 환경 구성
![img](/assets/category/DevOps/03/00.png)

# 2. SpringBoot Project Local Test
## Maven Project
- 프로젝트 빌드 : 프로젝트의 pom.xml 파일을 설정하고 Maven을 사용하여 프로젝트를 빌드합니다.
- JAR,WAR 파일 생성 : mvn package 명령어로 Spring 프로젝트를 빌드하여 JAR 파일을 생성합니다.

## Gradle Project
### 1). 프로젝트 빌드
프로젝트 내에 gradlew파일이 있는 디렉토리에서 gradlew build 명령어를 실행하여 jar,war파일을 생성합니다.
    
![img](/assets/category/DevOps/03/01.png)

```shell
# 명령어
gradlew build

Starting a Gradle Daemon, 5 incompatible and 1 stopped Daemons could not be reused, use --status for details

> Task :test
OpenJDK 64-Bit Server VM warning: Sharing is only supported for boot loader classes because bootstrap classpath has been appended

BUILD SUCCESSFUL in 1m 21s
7 actionable tasks: 7 executed
```

### 2). jar,war파일 생성 확인
위 과정을 거치면 /build/libs 폴더 내에 war 혹은 jar파일이 생성됩니다.
    ![img](/assets/category/DevOps/03/02.png)

### 3). 프로젝트 실행
/build/libs디렉토리로 이동하여 아래 명령어를 통해 로컬에서 프로젝트 구동을 확인합니다.
이클립스및 다른 툴을 이용하여 구동하는것도 좋습니다.
    ```shell
    # 명령어
    java -jar <project file name>.war
    java -jar <project file name>.jar
    
    # 8080외의 포트 지정 예) 6060포트
    java -jar -Dserver.port=6060 demo-war-0.0.1-SNAPSHOT.war
    ```

# 3. Remote Server 구성
Azure VM 생성: Azure 포털에서 새로운 가상 머신을 생성합니다. VM의 운영체제는 Ubuntu를 예로 들겠습니다.

- VM 설정
    - SSH를 통해 VM에 접근합니다.
    - Java 및 필요한 패키지 설치를 진행합니다.

    ```shell
    sudo apt update
    sudo apt install openjdk-17-jdk -y
    sudo apt install maven -y
    sudo apt install gradle
    ``` 

# 4. Jenkins Repository 연동
## 1. 새로운 item 생성
![img](/assets/category/DevOps/03/03.png)

## 2. 새로운 Job 생성: Jenkins 대시보드에서 새로운 Freestyle 프로젝트를 생성합니다.
![img](/assets/category/DevOps/03/04.png)

## 3. 소스 코드 관리 > Subversion을 선택합니다.
### Modules
1. Repository URL : SVN repository주소를 입력합니다.
![img](/assets/category/DevOps/03/05.png)

2. Credentials

    Jenkins 에서 빌드, 배포를 수행하려면 기본적으로 2가지 Credential 정보가 필요합니다. 
    소스를 Checkout 할 Git Repository 의 접속 계정 정보와 Docker Image를 Push 하기 위한 Registry 접속 계정 정보입니다.
    여기서는 SVN에 접속할 SVN 계정정보를 등록합니다.

3. Add를 클릭 후 Jenkins를 눌러줍니다.
![img](/assets/category/DevOps/03/06.png)

4. SVN관련 계정정보를 입력 후 Add로 추가합니다.
![img](/assets/category/DevOps/03/07.png)

-  세팅 참고 예)
![img](/assets/category/DevOps/03/08.png)
작성 완료 후 저장을 눌러 완료합니다.

# 5. Jenkins 배포 Pipeline 구성
1. Build Steps에서 Add build step을 눌러 Execute shell을 선택합니다.
![img](/assets/category/DevOps/03/14.png)
2. 아래 작성된 Build Steps를 참고하여 명령어를 입력 후 저장합니다.

### Build Steps 작성 참고
```shell
# gradlew 파일의 위치로 이동
cd demo-war

ls -l

chmod +x gradlew
./gradlew clean build --info

pwd

cd /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/build/libs/
java -jar -Dserver.port=6060 demo-war-0.0.1-SNAPSHOT.war
```
### Build Steps 수정 및 보완
```shell
#!/bin/bash
# gradlew 파일의 위치로 이동
cd /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war

# 현재 디렉토리와 파일 리스트 출력 (디버깅용)
pwd
ls -l

# gradlew 파일에 실행 권한 부여
chmod +x /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/gradlew

# gradlew 파일의 줄 바꿈 형식 변환
sed -i 's/\r//' /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/gradlew

# gradlew 파일이 존재하는지 확인 (디버깅용)
if [ -f /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/gradlew ]; then
    echo "gradlew 파일이 존재합니다."
else
    echo "gradlew 파일이 존재하지 않습니다. 스크립트를 종료합니다."
    exit 1
fi

# gradlew 파일 실행
/var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/gradlew clean build --info

# 현재 디렉토리 출력 (디버깅용)
pwd

# 빌드된 파일의 위치로 이동
cd /var/lib/jenkins/workspace/SpringBoot-Demo-war/demo-war/build/libs/

# war 6060포트로 Project 실행
java -jar -Dserver.port=6060 demo-war-0.0.1-SNAPSHOT.war
```

# 6. Jenkins Build
## 1. 지금 빌드를 클릭하여 Build를 진행합니다.
![img](/assets/category/DevOps/03/09.png)

## 2. 진행중인 Build번호를 클릭하여 Console 로그를 모니터링 합니다.
1. Build 번호 클릭
![img](/assets/category/DevOps/03/10.png)

2. Console Output 클릭
![img](/assets/category/DevOps/03/11.png)
실시간으로 로그를 모니터링 하면서 build과정을 관찰합니다.

1. 콘솔 출력
![img](/assets/category/DevOps/03/12.png)

# 7. 완료
서버 구동까지 완료가 되면 해당 VM의 웹으로 접근하여 성공여부를 확인합니다.
![img](/assets/category/DevOps/03/13.png)

---
# Error
## 아래와 같이 build에서 에러가 발생하는 경우

- ./gradlew: /bin/sh^M: bad interpreter: No such file or directory

윈도우 환경에서 build를 하는 경우 개행양식이 리눅스환경과 맞지않아 이와같은 에러가 발생하는듯 하다.

```shell
master@svn:/var/lib/jenkins/workspace/springboot/demo-war$ ./gradlew build
-bash: ./gradlew: /bin/sh^M: bad interpreter: No such file or directory
```

- 해결방안

```shell
#1.  dos2unix 설치
sudo dos2unix gradlew

#2. Unix 형식으로 변환 
dos2unix gradlew
``` 

---
# 개선방안
1. Build 사이클이 OneStep에서 Build 후 배포까지 끝나기 때문에 Jenkins에서 Build가 멈추지 않음
2. Build step과 Project 구동 분리가 필요
> 해당부분은 Github Actions 참고하면 될듯
3. Jenkins를 수동으로 직접설치해서 디렉토리를 관리할 수 있도록 하는게 필요
4. 아니면 Project Artifact를 별도로 다운로드하는 디렉토리 구분 시도
5. 추후, docker image를 Docker hub쪽으로 commit하는 방안 예정
6. 추후, Kubernetes를 이용한 CICD방식을 테스트해볼 예정