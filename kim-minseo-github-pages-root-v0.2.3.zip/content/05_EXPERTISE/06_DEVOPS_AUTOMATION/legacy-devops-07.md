---
id: legacy-devops-07
type: expertise
title: Gitlab 설치
enabled: true
sample: false
group: devops-automation
category: DevOps
createdDate: '2025-08-05'
updatedDate: '2025-08-05'
featured: false
summary: 'Gitlab 설치 1. 패키지 업데이트: VM에 접속한 후, 아래 명령어를 실행하여 패키지 리스트를 업데이트 2. 필수 소프트웨어
  설치 GitLab을 설치하기 위해 필요한 curl 및 Postfix를 설치 Postfix는 이메일 알림을 위해 사용 3. GitLab Re'
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# Gitlab 설치 
1. 패키지 업데이트: VM에 접속한 후, 아래 명령어를 실행하여 패키지 리스트를 업데이트
```shell
sudo apt-get update
sudo apt-get upgrade
```

2. 필수 소프트웨어 설치
    - GitLab을 설치하기 위해 필요한 curl 및 Postfix를 설치
    - Postfix는 이메일 알림을 위해 사용
```shell
sudo apt-get install -y curl openssh-server ca-certificates postfix

# 설치 중 Postfix 구성 화면이 나타나면, 'Internet Site'를 선택하고 도메인 이름을 설정
```

3. GitLab Repository 추가: GitLab의 공식 스크립트를 사용하여 GitLab CE (Community Edition) 저장소 추가
```shell
curl https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.deb.sh | sudo bash
```

4. GitLab 설치: 저장소가 추가되면, 다음 명령어로 GitLab을 설치
```shell
sudo EXTERNAL_URL="http://[VM의 공용 IP 주소]" apt-get install gitlab-ce
sudo EXTERNAL_URL="http://52.141.42.80" apt-get install gitlab-ce
```

5. 설치 완료 후 관리자 계정 비밀번호 확인(24시간 이후 자동삭제)
```shell
sudo cat /etc/gitlab/initial_root_password

# 명령어 실행
master@CICD:~$ sudo cat /etc/gitlab/initial_root_password
# WARNING: This value is valid only in the following conditions
#          1. If provided manually (either via `GITLAB_ROOT_PASSWORD` environment variable or via `gitlab_rails['initial_root_password']` setting in `gitlab.rb`, it was provided before database was seeded for the first time (usually, the first reconfigure run).
#          2. Password hasn't been changed manually, either via UI or via command line.
#
#          If the password shown here doesn't work, you must reset the admin password following https://docs.gitlab.com/ee/security/reset_user_password.html#reset-your-root-password.

Password: 2reHveD7jIBuyp4CZKVKTbJVtAMexGlJmOmyWeTeonA=

# NOTE: This file will be automatically deleted in the first reconfigure run after 24 hours.
```
- 관리자 계정 로그인 후 비밀번호 변경 필
    - ID : root
    - pw : 2reHveD7jIBuyp4CZKVKTbJVtAMexGlJmOmyWeTeonA=

- 초기 비밀번호가 이미 삭제된 경우
    1. GitLab Rails 콘솔에 접속: sudo gitlab-rails console
    2. root 사용자를 찾고 비밀번호를 재설정
        ```shell
        user = User.find_by_username('root')
        user.password = '새로운_비밀번호'
        user.password_confirmation = '새로운_비밀번호'
        user.save!
        ```
    3. 콘솔 종료 : exit
