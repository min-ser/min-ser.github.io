---
id: legacy-devops-01
type: expertise
title: SVN 설치 및 이클립스 연동
enabled: true
sample: false
group: devops-automation
category: DevOps
createdDate: '2024-06-14'
updatedDate: '2024-06-14'
featured: false
summary: '0. 실행환경 Azure VM OS : Ubuntu 20.04LTS 외부 접근 허용포트 Apache2 : 8080 svn : 3690
  web : 80,443 1. SVN 설치 1. 패키지 목록 업데이트 시스템의 패키지 목록 최신화 2. Subversion 설치 3. 설'
tags:
- SVN
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 0. 실행환경
- Azure VM
- OS : Ubuntu 20.04LTS

## 외부 접근 허용포트
- Apache2 : 8080
- svn : 3690
- web : 80,443

# 1. SVN 설치
## 1. 패키지 목록 업데이트
시스템의 패키지 목록 최신화
```shell
sudo apt update
```

## 2. Subversion 설치
```shell
sudo apt install subversion
```

## 3. 설치확인 [완료]
```shell
svn --version

# 명령어 실행
master@svn:~$ svn --version
svn, version 1.13.0 (r1867053)
   compiled May 12 2022, 20:47:08 on x86_64-pc-linux-gnu

Copyright (C) 2019 The Apache Software Foundation.
This software consists of contributions made by many people;
see the NOTICE file for more information.
Subversion is open source software, see http://subversion.apache.org/

The following repository access (RA) modules are available:

* ra_svn : Module for accessing a repository using the svn network protocol.
  - with Cyrus SASL authentication
  - handles 'svn' scheme
* ra_local : Module for accessing a repository on local disk.
  - handles 'file' scheme
* ra_serf : Module for accessing a repository via WebDAV protocol using serf.
  - using serf 1.3.9 (compiled with 1.3.9)
  - handles 'http' scheme
  - handles 'https' scheme

The following authentication credential caches are available:

* Gnome Keyring
* GPG-Agent
* KWallet (KDE)
```

# 2. SVN Repository 구성
## 1. 저장소(Repository) 생성
해당 구성환경에서 SVN Repository 경로를 지정합니다.
이때 저장소명은 Github의 repository명이라고 생각하면 됩니다.
```shell
# repository 생성 명령어
svnadmin create /home/user/repository

# 명령어 실행
master@svn:~$ mkdir svn
master@svn:~$ cd svn
master@svn:~/svn$ svnadmin create repository
```
- 체크아웃 [skip]
```shell
master@svn:~$ svn checkout file:///home/master/svn/repository/ /home/master/svn/repository_copy
```

## 2. 원격 접근 설정
원격으로 SVN 저장소에 접근하려면 Apache HTTP Server와 SVN의 WebDAV 모듈을 사용하여 설정할 수 있습니다. 
이 작업은 기본적인 SVN 사용을 위해 필수는 아니지만, 협업 환경에서 유용할 수 있습니다.
> SVN 사용자 계정은 Apache와 독리형 svnserve 두개로 나누어집니다. 여기서는 Apache형을 기준으로 기술하였습니다.
### [Apache] 1. Apache 및 모듈 설치
```shell
# 설치 명령어
sudo apt install apache2 libapache2-mod-svn

# 설치 진행
master@svn:~/svn$ sudo apt install apache2 libapache2-mod-svn

Reading package lists... Done
Building dependency tree
Reading state information... Done
The following additional packages will be installed:
  apache2-bin apache2-data apache2-utils libaprutil1-dbd-sqlite3 libaprutil1-ldap libjansson4 liblua5.2-0 ssl-cert
Suggested packages:
  apache2-doc apache2-suexec-pristine | apache2-suexec-custom www-browser db5.3-util openssl-blacklist
The following NEW packages will be installed:
  apache2 apache2-bin apache2-data apache2-utils libapache2-mod-svn libaprutil1-dbd-sqlite3 libaprutil1-ldap libjansson4 liblua5
0 upgraded, 10 newly installed, 0 to remove and 4 not upgraded.
Need to get 1784 kB of archives.
After this operation, 8003 kB of additional disk space will be used.
Do you want to continue? [Y/n] y
Get:1 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 libaprutil1-dbd-sqlite3 amd64 1.6.1-4ubuntu2.2 [10.5 kB]
Get:2 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 libaprutil1-ldap amd64 1.6.1-4ubuntu2.2 [8752 B]
Get:3 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 libjansson4 amd64 2.12-1build1 [28.9 kB]
Get:4 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 liblua5.2-0 amd64 5.2.4-1.1build3 [106 kB]
Get:5 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 apache2-bin amd64 2.4.41-4ubuntu3.17 [1187 kB]
Get:6 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 apache2-data all 2.4.41-4ubuntu3.17 [158 kB]
Get:7 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 apache2-utils amd64 2.4.41-4ubuntu3.17 [84.1 kB]
Get:8 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 apache2 amd64 2.4.41-4ubuntu3.17 [95.5 kB]
Get:9 http://azure.archive.ubuntu.com/ubuntu focal-updates/universe amd64 libapache2-mod-svn amd64 1.13.0-3ubuntu0.2 [87.3 kB]
Get:10 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 ssl-cert all 1.0.39 [17.0 kB]
Fetched 1784 kB in 4s (504 kB/s)
Preconfiguring packages ...
Selecting previously unselected package libaprutil1-dbd-sqlite3:amd64.
(Reading database ... 59109 files and directories currently installed.)
Preparing to unpack .../0-libaprutil1-dbd-sqlite3_1.6.1-4ubuntu2.2_amd64.deb ...
Unpacking libaprutil1-dbd-sqlite3:amd64 (1.6.1-4ubuntu2.2) ...
Selecting previously unselected package libaprutil1-ldap:amd64.
Preparing to unpack .../1-libaprutil1-ldap_1.6.1-4ubuntu2.2_amd64.deb ...
Unpacking libaprutil1-ldap:amd64 (1.6.1-4ubuntu2.2) ...
Selecting previously unselected package libjansson4:amd64.
Preparing to unpack .../2-libjansson4_2.12-1build1_amd64.deb ...
Unpacking libjansson4:amd64 (2.12-1build1) ...
Selecting previously unselected package liblua5.2-0:amd64.
Preparing to unpack .../3-liblua5.2-0_5.2.4-1.1build3_amd64.deb ...
Unpacking liblua5.2-0:amd64 (5.2.4-1.1build3) ...
Selecting previously unselected package apache2-bin.
Preparing to unpack .../4-apache2-bin_2.4.41-4ubuntu3.17_amd64.deb ...
Unpacking apache2-bin (2.4.41-4ubuntu3.17) ...
Selecting previously unselected package apache2-data.
Preparing to unpack .../5-apache2-data_2.4.41-4ubuntu3.17_all.deb ...
Unpacking apache2-data (2.4.41-4ubuntu3.17) ...
Selecting previously unselected package apache2-utils.
Preparing to unpack .../6-apache2-utils_2.4.41-4ubuntu3.17_amd64.deb ...
Unpacking apache2-utils (2.4.41-4ubuntu3.17) ...
Selecting previously unselected package apache2.
Preparing to unpack .../7-apache2_2.4.41-4ubuntu3.17_amd64.deb ...
Unpacking apache2 (2.4.41-4ubuntu3.17) ...
Selecting previously unselected package libapache2-mod-svn.
Preparing to unpack .../8-libapache2-mod-svn_1.13.0-3ubuntu0.2_amd64.deb ...
Unpacking libapache2-mod-svn (1.13.0-3ubuntu0.2) ...
Selecting previously unselected package ssl-cert.
Preparing to unpack .../9-ssl-cert_1.0.39_all.deb ...
Unpacking ssl-cert (1.0.39) ...
Setting up libaprutil1-ldap:amd64 (1.6.1-4ubuntu2.2) ...
Setting up libaprutil1-dbd-sqlite3:amd64 (1.6.1-4ubuntu2.2) ...
Setting up libjansson4:amd64 (2.12-1build1) ...
Setting up ssl-cert (1.0.39) ...
Setting up liblua5.2-0:amd64 (5.2.4-1.1build3) ...
Setting up apache2-data (2.4.41-4ubuntu3.17) ...
Setting up apache2-utils (2.4.41-4ubuntu3.17) ...
Setting up apache2-bin (2.4.41-4ubuntu3.17) ...
Setting up apache2 (2.4.41-4ubuntu3.17) ...
Enabling module mpm_event.
Enabling module authz_core.
Enabling module authz_host.
Enabling module authn_core.
Enabling module auth_basic.
Enabling module access_compat.
Enabling module authn_file.
Enabling module authz_user.
Enabling module alias.
Enabling module dir.
Enabling module autoindex.
Enabling module env.
Enabling module mime.
Enabling module negotiation.
Enabling module setenvif.
Enabling module filter.
Enabling module deflate.
Enabling module status.
Enabling module reqtimeout.
Enabling conf charset.
Enabling conf localized-error-pages.
Enabling conf other-vhosts-access-log.
Enabling conf security.
Enabling conf serve-cgi-bin.
Enabling site 000-default.
Created symlink /etc/systemd/system/multi-user.target.wants/apache2.service → /lib/systemd/system/apache2.service.
Created symlink /etc/systemd/system/multi-user.target.wants/apache-htcacheclean.service → /lib/systemd/system/apache-htcacheclea
Setting up libapache2-mod-svn (1.13.0-3ubuntu0.2) ...
apache2_invoke: Enable module dav_svn
apache2_invoke: Enable module authz_svn
Processing triggers for systemd (245.4-4ubuntu3.23) ...
Processing triggers for man-db (2.9.1-1) ...
Processing triggers for libc-bin (2.31-0ubuntu9.16) ...
Processing triggers for ufw (0.36-6ubuntu1.1) ...
```

### 2. Apache 설정 파일 편집
Apache 설정 파일을 열어 다음과 같은 구성을 추가합니다. /etc/apache2/mods-available/dav_svn.conf 파일을 편집합니다.

```shell
master@svn:~/svn$ sudo vi /etc/apache2/mods-available/dav_svn.conf
```

-  dav_svn.conf파일
    - SVNParentPath : 생성된 저장소의 실제 디렉토리 입력
    - AuthUserFile  : 
        - 사용자 인증 파일 경로
        - Apache가 사용자 인증을 위해 Subversion 리포지토리에 접근시 사용되는 경로
```shell
<Location /svn>
   DAV svn
   SVNParentPath /home/master/svn 

   # Basic Authentication
   AuthType Basic
   AuthName "Subversion Repository"
   AuthUserFile /etc/apache2/dav_svn.passwd

   # 제한 설정
   <LimitExcept GET PROPFIND OPTIONS REPORT>
      Require valid-user
   </LimitExcept>
</Location>
```

### 3. 사용자 인증 파일 생성

사용자(개발자)가 외부에서 repository에 접근하기위해 사용되는 사용자 인증 파일

```shell
# 명령어
sudo htpasswd -cm /etc/subversion/passwd user1

# 명령어 실행
master@svn:~$ sudo htpasswd -cm /etc/apache2/dav_svn.passwd user1
New password: # 사용할 비밀번호 입력
Re-type new password: # 비밀번호 재입력
Adding password for user user1
```

- 추가 사용자 계정 생성시 c 생략[skip]

```shell
sudo htpasswd -m /etc/subversion/passwd user2
```

- 비밀번호를 잃어버린 경우

```shell
# 명령어
sudo htpasswd /etc/subversion/passwd user1

New password: 
Re-type new password: 
Updating password for user user1
```

### 4. Apache 모듈 활성화
```shell
# Apache에 필요한 모듈 활성화
sudo a2enmod dav
sudo a2enmod dav_svn
sudo a2enmod authz_user

# 명령어 실행
master@svn:~$ sudo a2enmod dav
Module dav already enabled
master@svn:~$ sudo a2enmod dav_svn
Considering dependency dav for dav_svn:
Module dav already enabled
Module dav_svn already enabled
master@svn:~$ sudo a2enmod authz_user
Considering dependency authz_core for authz_user:
Module authz_core already enabled
Module authz_user already enabled
```

### 5. Apache 재시작
```shell
# 명령어
sudo systemctl restart apache2

# 명령어 실행
master@svn:~$ sudo systemctl restart apache2
```

### 6. 로컬 내 url 접속 테스트
```shell
master@svn:~$ curl http://127.0.0.1/svn/repository_copy
<?xml version="1.0" encoding="utf-8"?>
<D:error xmlns:D="DAV:" xmlns:m="http://apache.org/dav/xmlns" xmlns:C="svn:">
<C:error/>
<m:human-readable errcode="2">
Could not find the requested SVN filesystem
</m:human-readable>
</D:error>
```

### [Error] 다음과 같은 문제 발생시
```shell
master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>500 Internal Server Error</title>

 webmaster@localhost to inform them of the time this error occurred,
 and the actions you performed just before this error.</p>
<p>More information about this error may be available
in the server error log.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
```
- tail 명령어 실행

```shell
sudo tail -n 50 /var/log/apache2/error.log
```

- 실행 결과

```shell
[Mon Jun 17 08:49:28.884870 2024] [authz_core:error] [pid 3993:tid 140530005010176] [client 127.0.0.1:37672] AH01627: AuthType configured with no corresponding authorization directives
```

검색 결과  /etc/apache2/mods-enabled/dav_svn.conf파일에 문제있음을 확인 후 
해당 파일에서 Require valid-user에 주석이 걸린걸 확인 

- apache 재실행 후 다시 확인

```shell
master@svn:~/svn$ sudo systemctl restart apache2
master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="http://127.0.0.1/svn/repository/">here</a>.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
```

### 7. 외부 url 접근 테스트
![image](/assets/category/ETC/05/01.png)


# 3. Eclipse With SVN 연동
## 1. Subversive 설치
1. Help > Marketplace를 클릭
![image](/assets/category/ETC/05/02.png)

2. Eclipse Marketplace에서 svn을 검색하여 Serversive - SVN Team Provider 4.8을 설치한다.
![image](/assets/category/ETC/05/help.png)

## 2. svn Connector 설치
1. Help > Install New Software...를 클릭
![image](/assets/category/ETC/05/help.png)

2. 아래 이미지와 같이 url입력 후 설치를 진행한다.
- https://osspit.org/eclipse/subversive-connectors/

![image](/assets/category/ETC/05/03.png)

## 3. SVN 연동
1. window > show view > other... 에서 SVN Repositories를 열어준다.
![image](/assets/category/ETC/05/04.png)

2. 외부에서 접속했던 url경로와 생성한 계정정보를 입력한다.
![image](/assets/category/ETC/05/05.png)

3. 성공적으로 프로젝트를 불러온것을 확인할 수 있다.
![image](/assets/category/ETC/05/end.png)

---
# svnserve.service 파일 생성 및 자동실행 설정
## 1. SVN 서버 서비스 파일 생성
- 먼저, svnserve를 systemd 서비스로 관리할 수 있도록 서비스 파일을 만듭니다.
- /etc/systemd/system/svnserve.service 파일을 생성하고 다음 내용을 추가합니다.
 
```shell
[Unit]
Description=Subversion Server
After=network.target

[Service]
Type=forking
ExecStart=/usr/bin/svnserve -d -r /home/<user>/<svn 설치경로> --pid-file /run/svnserve.pid
ExecStop=/bin/kill -TERM $MAINPID
PIDFile=/var/run/svnserve.pid

[Install]
WantedBy=multi-user.target
```

위의 설정에서 /path/to/repository를 실제 SVN 저장소 경로로 변경합니다. 예를 들어, 저장소 경로가 /home/naster/svn라면 다음과 같이 변경합니다.

```shell
ExecStart=/usr/bin/svnserve -d -r /home/svn/repo
```

## 2. 서비스 파일 권한 설정
서비스 파일을 만든 후 권한을 설정합니다.
```shell
sudo chmod 644 /etc/systemd/system/svnserve.service
```

## 3. 서비스 등록 및 시작
서비스 파일을 만들고 권한을 설정한 후, systemd에 서비스를 등록하고 시작합니다.
```shell
sudo systemctl daemon-reload
sudo systemctl enable svnserve
sudo systemctl start svnserve
```

## 4. 서비스 상태 확인
서비스가 제대로 시작되었는지 확인합니다.
```shell
sudo systemctl status svnserve
```

이제 svnserve 서비스가 시스템 부팅 시 자동으로 시작되도록 설정되었습니다.

## 5. SVN 사용자 계정 생성 및 권한 설정
앞서 설명한 대로 svnserve.conf, passwd, authz 파일을 설정하여 SVN 서버의 사용자 계정 및 권한을 관리할 수 있습니다.

---

# [독립형 SVNSERVE] SVN 사용자 계정 생성 및 권한 설정
## 1. svnserve.conf 설정
- svnserve.conf 파일은 저장소의 conf 디렉토리에 있습니다. 이 파일에서 인증 및 권한 설정을 구성할 수 있습니다.
- 예를 들어, /path/to/repository/conf/svnserve.conf 파일을 열고 다음 내용을 수정합니다.

```shell
[general]
anon-access = none
auth-access = write
password-db = passwd
authz-db = authz
realm = MyFirstRepository
```

## 2. passwd 파일 설정
- passwd 파일은 사용자 계정 정보를 저장합니다. 
- /path/to/repository/conf/passwd 파일을 열고 다음과 같이 사용자 계정을 추가합니다.
```shell
[users]
username1 = password1
username2 = password2
```

username1과 username2는 사용자의 이름이며, password1과 password2는 해당 사용자의 비밀번호입니다.

## 3. authz 파일 설정
- authz 파일은 사용자 및 그룹의 권한을 설정합니다. 
- /path/to/repository/conf/authz 파일을 열고 다음 내용을 추가합니다.

```shell
[groups]
developers = username1, username2

[/]
@developers = rw
```

- [groups] 섹션에서는 사용자 그룹을 정의합니다.
- [/] 섹션에서는 저장소의 루트 디렉토리에 대한 권한을 설정합니다. 여기서 @developers 그룹에 읽기/쓰기(rw) 권한을 부여합니다.

## 4. 서비스 재시작
- 설정 파일을 수정한 후에는 SVN 서비스를 재시작해야 합니다.
```shell
sudo systemctl restart svnserve
```

## 예시
전체 설정을 예시로 정리하면 다음과 같습니다.

- /path/to/repository/conf/svnserve.conf:
```shell
[general]
anon-access = none
auth-access = write
password-db = passwd
authz-db = authz
realm = MyFirstRepository
```

-  /path/to/repository/conf/passwd:
```shell
[users]
john = johnpassword
jane = janepassword
```

- /path/to/repository/conf/authz:
```shell
[groups]
developers = john, jane
[/]
@developers = rw
```

이 설정으로 john과 jane이라는 두 사용자가 MyFirstRepository라는 SVN 저장소에 접근할 수 있으며, 두 사용자 모두 읽기 및 쓰기 권한을 갖게 됩니다. 필요한 경우 다른 디렉토리에 대한 세부적인 권한을 authz 파일에 추가로 설정할 수 있습니다.

---

# Commit & 연동에러 
![image](/assets/category/ETC/05/error01.png)

- 에러 상세내용
```shell
Share project was failed.
svn: E204900: Can't open file '/home/master/svn/springboot/db/txn-current-lock': Permission denied
svn: E175002: MKACTIVITY of '/svn/springboot/!svn/act/02570a4e-8d47-4747-a5a8-815146342634': 500 Internal Server Error (http://52.231.108.38)
```

- 아래 명령어를 통해 권한부여
 
```shell
sudo chown -R www-data:www-data /home/master/svn/springboot/
sudo chmod -R 775 /home/master/svn/jsp/

# 명령어 치기 전
@svn:~/svn$ ll
total 20
drwxrwxr-x 5 master     master     4096 Jun 28 04:39 ./
drwxr-xr-x 8 master     master     4096 Jun 28 03:58 ../
drwxrwxr-x 7 www-data www-data 4096 Jun 28 04:09 jsp/
drwxrwxr-x 7 master     master     4096 Jun 20 05:01 repository/
drwxrwxr-x 6 master     master     4096 Jun 28 04:39 springboot/

master@svn:~/svn$ sudo chown -R www-data:www-data /home/master/svn/springboot/

# 명령어 실행 후 변화 비교
master@svn:~/svn$ ll
total 20
drwxrwxr-x 5 master     master     4096 Jun 28 04:39 ./
drwxr-xr-x 8 master     master     4096 Jun 28 03:58 ../
drwxrwxr-x 7 www-data www-data 4096 Jun 28 04:09 jsp/
drwxrwxr-x 7 master     master     4096 Jun 20 05:01 repository/
drwxrwxr-x 7 www-data www-data 4096 Jun 28 04:46 springboot/
```

- 정상화 확인
![image](/assets/category/ETC/05/error02.png)
---

# 실제 구성 환경 VM Log
```shell
The authenticity of host '52.231.108.38 (52.231.108.38)' can't be established.
ECDSA key fingerprint is SHA256:UGbGmuILJZ1K6BC/SguaYG3kh2y/mh3DyeqkIFmDuxo.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes 
Warning: Permanently added '52.231.108.38' (ECDSA) to the list of known hosts.
master@52.231.108.38's password: 
Welcome to Ubuntu 20.04.6 LTS (GNU/Linux 5.15.0-1064-azure x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/pro

 System information as of Mon Jun 17 08:31:18 UTC 2024

  System load:  0.38              Processes:             130
  Usage of /:   5.1% of 28.89GB   Users logged in:       0
  Memory usage: 4%                IPv4 address for eth0: 10.0.100.4      
  Swap usage:   0%

Expanded Security Maintenance for Applications is not enabled.

0 updates can be applied immediately.

Enable ESM Apps to receive additional future security updates.
See https://ubuntu.com/esm or run: sudo pro status


The list of available updates is more than a week old.
To check for new updates run: sudo apt update


The programs included with the Ubuntu system are free software;
the exact distribution terms for each program are described in the       
individual files in /usr/share/doc/*/copyright.

Ubuntu comes with ABSOLUTELY NO WARRANTY, to the extent permitted by     
applicable law.

To run a command as administrator (user "root"), use "sudo <command>".   
See "man sudo_root" for details.

master@svn:~$ sudo apt update
Hit:1 http://azure.archive.ubuntu.com/ubuntu focal InRelease
Get:2 http://azure.archive.ubuntu.com/ubuntu focal-updates InRelease [128 kB]
Get:3 http://azure.archive.ubuntu.com/ubuntu focal-backports InRelease [128 kB]
Get:4 http://azure.archive.ubuntu.com/ubuntu focal-security InRelease [128 kB]
Get:5 http://azure.archive.ubuntu.com/ubuntu focal/universe amd64 Packages [8628 kB]
Get:6 http://azure.archive.ubuntu.com/ubuntu focal/universe Translation-en [5124 kB]
Get:7 http://azure.archive.ubuntu.com/ubuntu focal/universe amd64 c-n-f Metadata [265 kB]
Get:8 http://azure.archive.ubuntu.com/ubuntu focal/multiverse amd64 Packages [144 kB]
Get:9 http://azure.archive.ubuntu.com/ubuntu focal/multiverse Translation-en [104 kB]
Get:10 http://azure.archive.ubuntu.com/ubuntu focal/multiverse amd64 c-n-f Metadata [9136 B]
Get:11 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 Packages [3359 kB]
Get:12 http://azure.archive.ubuntu.com/ubuntu focal-updates/main Translation-en [528 kB]
Get:13 http://azure.archive.ubuntu.com/ubuntu focal-updates/restricted amd64 Packages [2979 kB]
Get:14 http://azure.archive.ubuntu.com/ubuntu focal-updates/restricted Translation-en [417 kB]
Get:15 http://azure.archive.ubuntu.com/ubuntu focal-updates/universe amd64 Packages [1194 kB]
Get:16 http://azure.archive.ubuntu.com/ubuntu focal-updates/universe Translation-en [287 kB]
Get:17 http://azure.archive.ubuntu.com/ubuntu focal-updates/universe amd64 c-n-f Metadata [25.7 kB]
Get:18 http://azure.archive.ubuntu.com/ubuntu focal-updates/multiverse amd64 Packages [26.2 kB]
Get:19 http://azure.archive.ubuntu.com/ubuntu focal-updates/multiverse Translation-en [7880 B]
Get:20 http://azure.archive.ubuntu.com/ubuntu focal-updates/multiverse amd64 c-n-f Metadata [620 B]
Get:21 http://azure.archive.ubuntu.com/ubuntu focal-backports/main amd64 
Packages [45.7 kB]
Get:22 http://azure.archive.ubuntu.com/ubuntu focal-backports/main Translation-en [16.3 kB]
Get:23 http://azure.archive.ubuntu.com/ubuntu focal-backports/main amd64 
c-n-f Metadata [1420 B]
Get:24 http://azure.archive.ubuntu.com/ubuntu focal-backports/restricted 
amd64 c-n-f Metadata [116 B]
Get:25 http://azure.archive.ubuntu.com/ubuntu focal-backports/universe amd64 Packages [25.0 kB]
Get:26 http://azure.archive.ubuntu.com/ubuntu focal-backports/universe Translation-en [16.3 kB]
Get:27 http://azure.archive.ubuntu.com/ubuntu focal-backports/universe amd64 c-n-f Metadata [880 B]
Get:28 http://azure.archive.ubuntu.com/ubuntu focal-backports/multiverse 
amd64 c-n-f Metadata [116 B]
Get:29 http://azure.archive.ubuntu.com/ubuntu focal-security/main amd64 Packages [2984 kB]
Get:30 http://azure.archive.ubuntu.com/ubuntu focal-security/main Translation-en [447 kB]
Get:31 http://azure.archive.ubuntu.com/ubuntu focal-security/restricted amd64 Packages [2863 kB]
Get:32 http://azure.archive.ubuntu.com/ubuntu focal-security/restricted Translation-en [401 kB]
Get:33 http://azure.archive.ubuntu.com/ubuntu focal-security/universe amd64 Packages [966 kB]
Get:34 http://azure.archive.ubuntu.com/ubuntu focal-security/universe Translation-en [204 kB]
Get:35 http://azure.archive.ubuntu.com/ubuntu focal-security/universe amd64 c-n-f Metadata [19.2 kB]
Get:36 http://azure.archive.ubuntu.com/ubuntu focal-security/multiverse amd64 Packages [24.0 kB]
Get:37 http://azure.archive.ubuntu.com/ubuntu focal-security/multiverse Translation-en [5904 B]
Get:38 http://azure.archive.ubuntu.com/ubuntu focal-security/multiverse amd64 c-n-f Metadata [548 B]
Fetched 31.5 MB in 5s (6160 kB/s) 
Reading package lists... Done
Building dependency tree       
Reading state information... Done
4 packages can be upgraded. Run 'apt list --upgradable' to see them.
master@svn:~$ sudo apt install subversion
Reading package lists... Done
Building dependency tree       
Reading state information... Done
The following additional packages will be installed:
  libapr1 libaprutil1 libserf-1-1 libsvn1 libutf8proc2
Suggested packages:
  db5.3-util libapache2-mod-svn subversion-tools
The following NEW packages will be installed:
  libapr1 libaprutil1 libserf-1-1 libsvn1 libutf8proc2 subversion
0 upgraded, 6 newly installed, 0 to remove and 4 not upgraded.
Need to get 2356 kB of archives.
After this operation, 10.3 MB of additional disk space will be used.     
Do you want to continue? [Y/n] y
Get:1 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 libapr1 amdSelecting previously unselected package subversion.
Preparing to unpack .../5-subversion_1.13.0-3ubuntu0.2_amd64.deb ...     
Unpacking subversion (1.13.0-3ubuntu0.2) ...
Setting up libutf8proc2:amd64 (2.5.0-1) ...
Setting up libapr1:amd64 (1.6.5-1ubuntu1) ...
Setting up libaprutil1:amd64 (1.6.1-4ubuntu2.2) ...
Setting up libserf-1-1:amd64 (1.3.9-8build1) ...
Setting up libsvn1:amd64 (1.13.0-3ubuntu0.2) ...
Setting up subversion (1.13.0-3ubuntu0.2) ...
Processing triggers for libc-bin (2.31-0ubuntu9.16) ...
Processing triggers for man-db (2.9.1-1) ...
master@svn:~$ suv --version

Command 'suv' not found, did you mean:

  command 'sup' from deb sup (20100519-1build1)
  command 'sqv' from deb sqv (0.14.0-1)
  command 'sum' from deb coreutils (8.30-3ubuntu2)
  command 'su1' from deb hxtools (20200126-1build1)
  command 'su' from deb util-linux (2.34-0.1ubuntu9.4)
  command 'sur' from deb subtle (0.11.3224-xi-2.2build3)
  command 'sv' from deb runit (2.1.2-9.2ubuntu1)

Try: sudo apt install <deb name>

master@svn:~$ svn --version
svn, version 1.13.0 (r1867053)
   compiled May 12 2022, 20:47:08 on x86_64-pc-linux-gnu

Copyright (C) 2019 The Apache Software Foundation.
This software consists of contributions made by many people;
see the NOTICE file for more information.
Subversion is open source software, see http://subversion.apache.org/

The following repository access (RA) modules are available:

* ra_svn : Module for accessing a repository using the svn network protocol.
  - with Cyrus SASL authentication
  - handles 'svn' scheme
* ra_local : Module for accessing a repository on local disk.
  - handles 'file' scheme
* ra_serf : Module for accessing a repository via WebDAV protocol using serf.
  - using serf 1.3.9 (compiled with 1.3.9)
  - handles 'http' scheme
  - handles 'https' scheme

The following authentication credential caches are available:

* Gnome Keyring
* GPG-Agent
* KWallet (KDE)

master@svn:~$ mkdir svn
master@svn:~$ cd svn
master@svn:~/svn$ svnadmin create repository
master@svn:~/svn$ sudo apt install apache2 libapache2-mod-svn
Reading package lists... Done
Building dependency tree       
Reading state information... Done
The following additional packages will be installed:
  apache2-bin apache2-data apache2-utils libaprutil1-dbd-sqlite3 libaprutil1-ldap libjansson4
  liblua5.2-0 ssl-cert
Suggested packages:
  apache2-doc apache2-suexec-pristine | apache2-suexec-custom www-browser db5.3-util
  openssl-blacklist
The following NEW packages will be installed:
  apache2 apache2-bin apache2-data apache2-utils libapache2-mod-svn libaprutil1-dbd-sqlite3
  libaprutil1-ldap libjansson4 liblua5.2-0 ssl-cert
0 upgraded, 10 newly installed, 0 to remove and 4 not upgraded.
Need to get 1784 kB of archives.
After this operation, 8003 kB of additional disk space will be used.
Do you want to continue? [Y/n] y
Get:1 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 libaprutil1-dbd-sqlite3 6.1-4ubuntu2.2 [10.5 kB]
Get:2 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 libaprutil1-ldap amd64 1untu2.2 [8752 B]
Get:3 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 libjansson4 amd64 2.12-1build1 [Get:4 http://azure.archive.ubuntu.com/ubuntu focal/main amd64 liblua5.2-0 amd64 5.2.4-1.1buildB]
Get:5 http://azure.archive.ubuntu.com/ubuntu focal-updates/main amd64 apache2-bin amd64 2.4.41
  # To enable authorization via mod_authz_svn (enable that module separately):
Created symlink /etc/systemd/system/multi-user.target.wants/apache2.service → /lib/systemd/syshe2.service.
Created symlink /etc/systemd/system/multi-user.target.wants/apache-htcacheclean.service → /lib/system/apache-htcacheclean.service.
Setting up libapache2-mod-svn (1.13.0-3ubuntu0.2) ...
apache2_invoke: Enable module dav_svn
apache2_invoke: Enable module authz_svn
Processing triggers for systemd (245.4-4ubuntu3.23) ...
Processing triggers for man-db (2.9.1-1) ...
Processing triggers for libc-bin (2.31-0ubuntu9.16) ...
Processing triggers for ufw (0.36-6ubuntu1.1) ...
master@svn:~/svn$ sudo vi /etc/apache2/mods-available/dav_svn.conf
master@svn:~/svn$ sudo htpasswd -cm /etc/subversion/passwd user1
New password: 
Re-type new password: 
Adding password for user user1
master@svn:~/svn$ sudo a2enmod dav
v_svn
sudo a2enmod authz_userModule dav already enabled
master@svn:~/svn$ sudo a2enmod dav_svn
Considering dependency dav for dav_svn:
Module dav already enabled
Module dav_svn already enabled
master@svn:~/svn$ sudo a2enmod authz_user
Considering dependency authz_core for authz_user:
Module authz_core already enabled
Module authz_user already enabled
master@svn:~/svn$ sudo systemctl restart apache2
master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>500 Internal Server Error</title>
</head><body>
<h1>Internal Server Error</h1>
<p>The server encountered an internal error or
misconfiguration and was unable to complete
your request.</p>
<p>Please contact the server administrator at
 webmaster@localhost to inform them of the time this error occurred,
 and the actions you performed just before this error.</p>
<p>More information about this error may be available
in the server error log.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
master@svn:~/svn$ sudo systemctl restart apache2
master@svn:~/svn$ sudo ststemctl status apache2
sudo: ststemctl: command not found
master@svn:~/svn$ sudo systemctl status apache2
● apache2.service - The Apache HTTP Server
     Loaded: loaded (/lib/systemd/system/apache2.service; enabled; vendor preset: enabled)
     Active: active (running) since Mon 2024-06-17 08:48:02 UTC; 50s ago
       Docs: https://httpd.apache.org/docs/2.4/
    Process: 3987 ExecStart=/usr/sbin/apachectl start (code=exited, status=0/SUCCESS)
   Main PID: 3992 (apache2)
      Tasks: 55 (limit: 9456)
     Memory: 9.7M
     CGroup: /system.slice/apache2.service
             ├─3992 /usr/sbin/apache2 -k start
             ├─3993 /usr/sbin/apache2 -k start
             └─3994 /usr/sbin/apache2 -k start

Jun 17 08:48:02 svn systemd[1]: Starting The Apache HTTP Server...
Jun 17 08:48:02 svn apachectl[3990]: [Mon Jun 17 08:48:02.966247 2024] [so:warn] [pid 3990] AH
Jun 17 08:48:02 svn systemd[1]: Started The Apache HTTP Server.

master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>500 Internal Server Error</title>
</head><body>
<h1>Internal Server Error</h1>
<p>The server encountered an internal error or
misconfiguration and was unable to complete
your request.</p>
<p>Please contact the server administrator at
 webmaster@localhost to inform them of the time this error occurred,
 and the actions you performed just before this error.</p>
<p>More information about this error may be available
in the server error log.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
master@svn:~/svn$ ls
repository
master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>500 Internal Server Error</title>

 webmaster@localhost to inform them of the time this error occurred,
 and the actions you performed just before this error.</p>
<p>More information about this error may be available
in the server error log.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
master@svn:~/svn$ sudo vi /etc/apache2/mods-enabled/dav
dav.load      dav_svn.conf  dav_svn.load
master@svn:~/svn$ sudo vi /etc/apache2/mods-enabled/dav
dav.load      dav_svn.conf  dav_svn.load
master@svn:~/svn$ sudo vi /etc/apache2/mods-enabled/dav_svn.conf
master@svn:~/svn$ sudo vi /etc/apache2/mods-enabled/dav_svn.conf 
master@svn:~/svn$ sudo systemctl status apache2
● apache2.service - The Apache HTTP Server
     Loaded: loaded (/lib/systemd/system/apache2.service; enabled; vendor preset: enabled)    
     Active: active (running) since Mon 2024-06-17 08:48:02 UTC; 8min ago
       Docs: https://httpd.apache.org/docs/2.4/
    Process: 3987 ExecStart=/usr/sbin/apachectl start (code=exited, status=0/SUCCESS)
   Main PID: 3992 (apache2)
      Tasks: 55 (limit: 9456)
     Memory: 9.8M
     CGroup: /system.slice/apache2.service
             ├─3992 /usr/sbin/apache2 -k start
             ├─3993 /usr/sbin/apache2 -k start
             └─3994 /usr/sbin/apache2 -k start

master@svn:~/svn$ sudo systemctl restart apache2
master@svn:~/svn$ curl 127.0.0.1/svn/repository
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="http://127.0.0.1/svn/repository/">here</a>.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at 127.0.0.1 Port 80</address>
</body></html>
master@svn:~/svn$ 
```