---
id: legacy-jenkins-01
type: expertise
title: 'Ubuntu 20.04 : Jenkins 설치'
enabled: true
sample: false
group: devops-automation
category: Jenkins
createdDate: '2023-11-09'
updatedDate: '2023-11-09'
featured: false
summary: '젠킨스는 오픈 소스 CI/CD 도구로, 소프트웨어 개발 프로젝트를 자동화하는 데 사용됩니다. 1. 시스템 업데이트 및 패키지 설치:
  먼저 시스템을 최신 상태로 업데이트하고, 설치에 필요한 패키지를 설치합니다. 2. 젠킨스 설치: 젠킨스는 공식 Ubuntu 패키지 저장소'
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

젠킨스는 오픈 소스 CI/CD 도구로, 소프트웨어 개발 프로젝트를 자동화하는 데 사용됩니다.

# 1. 시스템 업데이트 및 패키지 설치:    
먼저 시스템을 최신 상태로 업데이트하고, 설치에 필요한 패키지를 설치합니다.
```
sudo apt update
sudo apt upgrade
sudo apt install openjdk-11-jdk
```

# 2. 젠킨스 설치:
젠킨스는 공식 Ubuntu 패키지 저장소에 없기 때문에, 젠킨스 웹사이트에서 제공하는 DEB 파일을 다운로드하여 설치합니다.
```
wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /Jenkins/apt/sources.list.d/jenkins.list'
sudo apt update
sudo apt install jenkins
```

# [Error] GPG키 오류 해결
```
jenkins@Jenkins:~$ sudo apt update
Hit:1 http://azure.archive.ubuntu.com/ubuntu focal InRelease
Hit:2 http://azure.archive.ubuntu.com/ubuntu focal-updates InRelease
Hit:3 http://azure.archive.ubuntu.com/ubuntu focal-backports InRelease
Hit:4 http://azure.archive.ubuntu.com/ubuntu focal-security InRelease
Ign:5 https://pkg.jenkins.io/debian-stable binary/ InRelease
Get:6 https://pkg.jenkins.io/debian-stable binary/ Release [2044 B]
Get:7 https://pkg.jenkins.io/debian-stable binary/ Release.gpg [833 B]
Ign:7 https://pkg.jenkins.io/debian-stable binary/ Release.gpg
Reading package lists... Done
W: GPG error: https://pkg.jenkins.io/debian-stable binary/ Release: The following signatures couldn't be verified because the public key is not available: NO_PUBKEY 5BA31D57EF5975CA
E: The repository 'http://pkg.jenkins.io/debian-stable binary/ Release' is not signed.
N: Updating from such a repository can't be done securely, and is therefore disabled by default.
N: See apt-secure(8) manpage for repository creation and user configuration details.
```
- 해결방안    
    GPG 키 오류를 해결하려면 다음 명령을 사용하여 GPG 키를 신뢰하도록 설정합니다. 5BA31D57EF5975CA는 GPG 키의 지문(fingerprint)입니다. 아래 명령어에서 [KEY_ID] 부분을 실제 키의 지문으로 바꾸세요.
    ```
    sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys [KEY_ID]
    ```

- 예시
    ```
    sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys 5BA31D57EF5975CA
    ```

# 3. Jenkins 서비스 시작:    
설치가 완료되면 Jenkins 서비스를 시작하고 부팅 시 자동으로 실행되도록 설정합니다.
```
sudo systemctl start jenkins
sudo systemctl enable jenkins
```

# 4. Jenkins 웹 인터페이스에 액세스:
웹 브라우저를 열고 http://your_server_ip_or_domain:8080 주소로 이동합니다. 
![img](/assets/category/Jenkins/01-01.png)

# 5. Jenkins 초기 암호 확인:
Jenkins 초기 설정 암호를 확인하려면 다음 명령어를 실행합니다.
```
sudo cat /var/lib/jenkins/secrets/initialAdminPassword
```
![img](/assets/category/Jenkins/01-02.png)

# 6. 초기 비밀번호 입력
![img](/assets/category/Jenkins/01-03.png)

# 7. 플러그인 설치:
![img](/assets/category/Jenkins/01-04.png)
Jenkins를 처음 설치하면 "Install suggested plugins" 및 "Select plugins to install" 두 가지 옵션이 제공됩니다. 어떤 옵션을 선택할지는 사용 사례 및 요구 사항에 따라 다를 수 있습니다.

- Install suggested plugins (제안된 플러그인 설치):   
    이 옵션을 선택하면 Jenkins가 기본적으로 추천하는 플러그인을 자동으로 설치합니다.
    이것은 Jenkins를 빠르게 설정하고 기본 기능을 활용하는 데 도움이 될 수 있습니다.
    이 방법은 Jenkins를 간단하게 시작하려는 경우에 유용하며, 나중에 필요한 플러그인을 추가로 설치할 수 있습니다.

- Select plugins to install (설치할 플러그인 선택):    
    이 옵션을 선택하면 특정한 플러그인을 수동으로 선택하여 설치할 수 있습니다.
    사용 사례에 따라 필요한 플러그인을 직접 선택할 수 있으므로 정교한 커스터마이징이 가능합니다.
    불필요한 플러그인을 설치하지 않아도 되기 때문에 불필요한 리소스 사용을 피할 수 있습니다.
    어떤 옵션을 선택할지는 프로젝트 및 요구 사항에 따라 다릅니다. 일반적으로는 "Install suggested plugins"을 선택하고 Jenkins를 빠르게 설정한 후 필요한 플러그인을 나중에 추가로 설치하는 것이 편리할 수 있습니다. 나중에 필요한 플러그인을 설치하려면 Jenkins 대시보드에서 "Manage Jenkins" > "Manage Plugins"로 이동하여 플러그인을 설치하거나 업데이트할 수 있습니다.
![img](/assets/category/Jenkins/01-05.png)
![img](/assets/category/Jenkins/01-06.png)


# 7. 작업 생성:
Jenkins 작업을 생성하고 설정합니다. 이를 통해 CI/CD 파이프라인을 구축하고 자동화된 빌드 및 배포를 수행할 수 있습니다.

이제 Ubuntu 20.04에 Jenkins가 설치되었고, 여러분은 CI/CD 프로세스를 구축하고 사용할 수 있습니다. 이 과정을 통해 소프트웨어 개발 프로젝트를 효율적으로 관리하고 자동화할 수 있습니다.
- [github와 jenkins 연동하기](https://2mukee.tistory.com/239)
- [Jenkins를 활용한 SpringBoot gradle 빌드&배포](https://velog.io/@mooh2jj/jenkins-docker-gradle-%EC%9E%90%EB%8F%99%EB%B0%B0%ED%8F%AC)