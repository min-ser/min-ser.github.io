---
id: legacy-jenkins-03
type: expertise
title: Jenkins Build용 Node 구성
enabled: true
sample: false
group: devops-automation
category: Jenkins
createdDate: '2024-07-30'
updatedDate: '2024-07-30'
featured: false
summary: '1. Jenkins Build용 VM 환경 구성 1 VM 환경 OS : Ubuntu 20.04 LTS JDK 17 Gradle Maven
  Docker kubectl <br <br <br 2 JDK, Gradle, Maven 설치 <br <br <br 3 Docker 환'
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 1. Jenkins Build용 VM 환경 구성
## 1) VM 환경
- OS : Ubuntu 20.04 LTS
- JDK 17
- Gradle
- Maven
- Docker
- kubectl

---
<br><br><br>

## 2) JDK, Gradle, Maven 설치
```shell
sudo apt update
sudo apt-get install openjdk-17-jdk -y
sudo apt  install gradle -y
sudo apt install maven -y
``` 
---
<br><br><br>

## 3) Docker 환경 구성
### 1. Docker 설치
```shell
sudo wget -qO- http://get.docker.com/ | sh

```
### 2. Docker 활성화
```shell
sudo systemctl enable docker
sudo systemctl start docker
sudo systemctl enable containerd
sudo systemctl start containerd
```

### 3. Docker 컨테이너 실행 테스트
```shell
jenkins-agent@Jenkins-Agent:~$ sudo docker run --rm hello-world
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
c1ec31eb5944: Pull complete
Digest: sha256:1408fec50309afee38f3535383f5b09419e6dc0925bc69891e79d84cc4cdcec6
Status: Downloaded newer image for hello-world:latest

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```

### 4. 생성된 Docker image 삭제
```shell
jenkins-agent@Jenkins-Agent:~$ sudo docker rmi $(sudo docker images -q)
Untagged: hello-world:latest
Untagged: hello-world@sha256:1408fec50309afee38f3535383f5b09419e6dc0925bc69891e79d84cc4cdcec6
Deleted: sha256:d2c94e258dcb3c5ac2798d32e1249e42ef01cba4841c2234249495f87264ac5a
Deleted: sha256:ac28800ec8bb38d5c35b49d45a6ac4777544941199075dff8c4eb63e093aa81e

jenkins-agent@Jenkins-Agent:~$ sudo docker images
REPOSITORY   TAG       IMAGE ID   CREATED   SIZE
```

### 5. Docker의 cgroup driver를 cgroupfs에서 systemd로 변경
```shell
#sudo mkdir /etc/docker
cat <<EOF | sudo tee /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2"
}
EOF

# 재시작
sudo systemctl enable docker
sudo systemctl daemon-reload
sudo systemctl restart docker  

# 변경된 cgroup driver 확인
sudo docker info | grep -i cgroup
```

### 6. Swap 메모리를 비활성화 [root 권한 필요]
```shell
# swap disable
swapoff -a
echo 0 > /proc/sys/vm/swappiness
sed -e '/swap/ s/^#*/#/' -i /etc/fstab

# 실행 참고
jenkins-agent@Jenkins-Agent:~$ sudo su -
root@Jenkins-Agent:~# swapoff -a
root@Jenkins-Agent:~# echo 0 > /proc/sys/vm/swappiness
root@Jenkins-Agent:~# sed -e '/swap/ s/^#*/#/' -i /etc/fstab
```

---
<br><br><br>

## 4) Kubectl 설치
### 1. apt-key를 통해 GPG 키 추가
```shell
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -

```

### 2. Kubernetes 패키지 저장소를 APT 소스 목록에 추가
```shell
cat <<EOF | sudo tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF
```

### 3. APT 패키지 목록 업데이트
```shell
sudo apt-get update
```

### 4. kubernetes 설치
```shell
sudo apt-get install -y kubelet kubeadm kubectl
sudo apt-mark hold kubelet kubeadm kubectl
sudo apt-get update

sudo kubeadm init --pod-network-cidr=10.244.0.0/16 --apiserver-advertise-address=10.0.100.6
```

### 5. kubectl 설치 확인
```shell
jenkins-agent@Jenkins-Agent:~$ kubectl get pods
E0730 04:50:54.162684   25615 memcache.go:265] couldn't get current server API group list: Get "http://localhost:8080/api?timeout=32s": dial tcp 127.0.0.1:8080: connect: connection refused

E0730 04:50:54.163036   25615 memcache.go:265] couldn't get current server API group list: Get "http://localhost:8080/api?timeout=32s": dial tcp 127.0.0.1:8080: connect: connection refused

E0730 04:50:54.164441   25615 memcache.go:265] couldn't get current server API group list: Get "http://localhost:8080/api?timeout=32s": dial tcp 127.0.0.1:8080: connect: connection refused

E0730 04:50:54.164754   25615 memcache.go:265] couldn't get current server API group list: Get "http://localhost:8080/api?timeout=32s": dial tcp 127.0.0.1:8080: connect: connection refused

E0730 04:50:54.166074   25615 memcache.go:265] couldn't get current server API group list: Get "http://localhost:8080/api?timeout=32s": dial tcp 127.0.0.1:8080: connect: connection refused
The connection to the server localhost:8080 was refused - did you specify the right host or port?
```

### 6. Kubeconfig 파일 설정
```shell
sudo mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config

```

---
<br><br><br>

# 2. Kubernetes plugin for Jenkins 설치하기
## 1) Plugin 설치
### 1. Jenkins관리 > Plugins경로로 들어가 Kubernetes를 검색해서 해당 플러그인을 설치
![img](/assets/category/Jenkins/03/01.png)

### 2. 설치 후 메인페이지 진입
![img](/assets/category/Jenkins/03/02.png)

## 2). Kubernetes 클러스터 정보 설정
### 1. Jenkins관리 > Clouds경로에 접근하여 New cloud를 눌러 설정 진행
![img](/assets/category/Jenkins/03/03.png)

### 2. Cloud name을 적절하게 입력 후 Kubernetes타입을 선택한뒤 Create를 눌러 진행
![img](/assets/category/Jenkins/03/04.png)

---
<br><br><br>