---
id: legacy-jenkins-02
type: expertise
title: Jenkins Job Pipeline 구성
enabled: true
sample: false
group: devops-automation
category: Jenkins
createdDate: '2024-07-25'
updatedDate: '2024-07-25'
featured: false
summary: 환경 구성 SpringBoot 3.4 Gradle war <br <br <br Jenkins Pipeline Job 생성 새로운 item을
  누른다. img /assets/category/Jenkins/02/01.png Pipeline을 선택한 후 OK img /asse
tags:
- Jenkins
---

> **Legacy Engineering Note** · 기존 기술 블로그에서 선별 이관한 기록입니다. 작성 당시 환경과 버전을 기준으로 합니다.

# 환경 구성
- SpringBoot 3.4
- Gradle
- war

---
<br><br><br>

# Jenkins Pipeline Job 생성
## 새로운 item을 누른다.
![img](/assets/category/Jenkins/02/01.png)


## Pipeline을 선택한 후 OK
![img](/assets/category/Jenkins/02/02.png)


## Configure > Pipeline
1. Definition에 Pipeline script from SCM 선택 후 SCM에 연결할 repository type 선택
    ![img](/assets/category/Jenkins/02/03.png)
2. 다음과 같이 Modules 작성
    ![img](/assets/category/Jenkins/02/04.png)
    - Repository URL : 연결할 repository 주소
    - Credentials : 해당 repository 접속을 위한 Jenkins에 등록된 아이디 선택
    - Local module directory : 
    
        Jenkins Pipeline에서 소스 코드 저장소를 체크아웃할 때, 워크스페이스의 어느 디렉토리에 체크아웃할지를 지정하는 옵션
3. Script Path에서 해당 프로젝트에 생성된 Jenkinsfile경로 등록
    ![img](/assets/category/Jenkins/02/05.png)

### Jenkinsfile 작성 예시 참고[추후 정리 필요]
```shell
pipeline {
    agent any

    // 환경변수 저장
    environment {
        DOCKER_IMAGE = 'iiblackcode/springboot-6060'
        REMOTE_DIR = '/home/master' // 원격 서버의 대상 디렉토리
        REMOTE_USER = 'master' // 원격 서버의 사용자 이름
        REMOTE_HOST = '52.141.27.193' // 원격 서버의 주소
        SSH_CREDENTIALS_ID = 'master' // Jenkins 자격 증명 ID
    }

    stages {
        stage('Jenkins Server Build') {
            steps {
                // 현재 작업 디렉토리 확인
                sh 'pwd'
                // 디렉토리 변경 후 파일 확인
                dir('demo-war') {
                    sh '''
                        pwd
                        ls -l
                        
                        # windows에서 작업하는 경우 gradlew파일이 text로 인식해서 올바른 형식 변환
                        dos2unix gradlew
                        chmod +x gradlew
                        ./gradlew clean build --info
                    '''
                }
            }
        }// Jenkins Server Build
        
        stage('Test') {
            steps {
                dir('demo-war') {
                    sh './gradlew test'
                }
            }
        }
        
        stage('Deploy to Remote Server') {
            steps {
                echo 'Deploying...'
                sh 'pwd'
                    
                echo 'Deploying...'
                sshPublisher(
                    publishers: [
                        sshPublisherDesc(
                            configName: 'JenkinsPipeline_Test', // 설정된 서버 이름
                            transfers: [
                                sshTransfer(
                                    sourceFiles: '**/demo-war-0.0.1-SNAPSHOT.war',
                                    remoteDirectory: '.',
                                    removePrefix: 'demo-war/build/libs/',
                                    execCommand: '''
                                    echo "현재 디렉토리 출력"
                                    pwd
                                    cd was/Jenkins_Pipeline_Test
                                    
                                    whoami
                                    
                                    echo "현재 날짜와 시간으로 태그 생성"
                                    TIMESTAMP=$(date +"%Y%m%d%H%M%S")
                                    DOCKER_IMAGE="iiblackcode/springboot-6060"
                                    TAG="$DOCKER_IMAGE:$TIMESTAMP"
                                    
                                    echo "Docker 이미지 강제 삭제 (기존 이미지 태그가 있는 경우)"
                                    # sudo docker rmi -f $TAG || true
                                    sudo docker rmi $(sudo docker images -q)
                                    
                                    echo "Docker 이미지 빌드"
                                    sudo docker build -t $TAG .
                                    
                                    echo "생성된 Docker image 확인"
                                    sudo docker images
                                    
                                    echo "Docker hub login or ACR 등록"
                                    sudo docker login
                                    
                                    echo "Docker 이미지 푸시"
                                    sudo docker push $TAG
                                    
                                    
                                    # sudo docker run -it -d -p 6060:8080 springboot-6060
                                    # sudo docker ps -a
                                    
                                    echo "yaml파일 경로로 이동"
                                    cd ../../web/
                                    ls
                                    
                                    echo "deployment.yaml 파일 업데이트"
                                    # sed -i "s|image: iiblackcode/springboot-6060:.*|image: \$TAG|" deployment.yaml
                                    sed -i "s|image: iiblackcode/springboot-6060:.*|image: $TAG|" deployment.yaml
                                    
                                    echo "업데이트된 deployment.yaml 파일 내용 확인"
                                    cat deployment.yaml
                                    
                                    echo "Deployment.yaml 재실행"
                                    kubectl apply -f deployment.yaml
                                    ''',
                                    execTimeout: 120000
                                )
                            ],
                            usePromotionTimestamp: false,
                            useWorkspaceInPromotion: false,
                            verbose: true
                        )
                    ]
                )
                
            }
        }// Deploy to Remote Server
    }

    post {
        success {
            echo 'Build completed successfully!'
        }
        failure {
            echo 'Build failed!'
        }
    }
}
```
---
<br><br><br>