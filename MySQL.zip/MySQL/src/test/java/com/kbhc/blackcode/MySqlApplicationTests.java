package com.kbhc.blackcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
