CREATE TABLE data (
	num int NOT NULL AUTO_INCREMENT,
	contents text NULL,
	date timestamp NULL,
	CONSTRAINT data_pkey PRIMARY KEY (num)
);

select * from data;