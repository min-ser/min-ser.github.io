package knou;

import java.util.Scanner;

public class Quize2 {

	public static void run() {
		System.out.println("==== 문제2 ====");
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);  
		  
        // 사용자로부터 정수 입력받기  
        System.out.print("정수를 입력하세요: ");  
        int number = scanner.nextInt();  
  
        // 정수를 문자열로 변환하고 뒤집기  
        String reversedString = new StringBuilder(String.valueOf(number)).reverse().toString();  
  
        // 결과 출력  
        System.out.println("뒤집힌 정수: " + reversedString);  
  
        scanner.close();
	}

}