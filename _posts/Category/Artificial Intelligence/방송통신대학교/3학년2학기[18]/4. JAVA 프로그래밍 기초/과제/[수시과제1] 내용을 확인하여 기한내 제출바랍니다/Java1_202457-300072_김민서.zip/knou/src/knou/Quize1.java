package knou;

import java.util.Scanner;

public class Quize1 {

	// 최대공약수 계산 함수(유클리드 호제법)
    public static int gcd(int a, int b) {  
        while (b != 0) {  
            int temp = b;  
            b = a % b;  
            a = temp;  
        }  
        return a;  
    }  
  
    // 최소공배수 계산 함수(유클리드 호제법)
    public static int lcm(int a, int b) {  
        return (a * b) / gcd(a, b);  
    } 
    
	public static void run() {
		// TODO Auto-generated method stub
		System.out.println("==== 문제1 ====");
		Scanner scanner = new Scanner(System.in);  
		  
        System.out.print("첫 번째 정수를 입력하세요: ");  
        int num1 = scanner.nextInt();  
        System.out.print("두 번째 정수를 입력하세요: ");  
        int num2 = scanner.nextInt();  
  
        int gcd = gcd(num1, num2);  
        int lcm = lcm(num1, num2);  
  
        System.out.println("최대공약수: " + gcd);  
        System.out.println("최소공배수: " + lcm);  
  
//        scanner.close();

	}

}
