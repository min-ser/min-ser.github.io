package knou;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Quize1.run();
//		Quize2.run();
		int a = 2;
		int b = 2;
		
		if (a == 1) 
			if (b == 2) 
				System.out.println("a was 1 and b was 2.");
		else 
			System.out.println("a wasn't 1");
		
	}

}