#include <stdio.h>

int main(void)
{
	int a = 100;

	int byte = sizeof (double);
	printf("double ��: %d bytes, %d bits\n", byte, byte * 8);

	int bit = (byte = sizeof a, byte * 8);
	printf("int ��: %d bytes, %d bits\n", byte, bit);

	return 0;
}
