#include <stdio.h>

int main()
{
	printf("hello, world");
	int $data = 10;
	return 0;
}