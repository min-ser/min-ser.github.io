#include <stdio.h>  
#include <stdlib.h>  
#include <time.h>  
  
// 숫자를 맞추는 게임 함수  
void guess_the_number() {  
    int number_to_guess, user_guess, attempts; // 맞춰야 할 숫자, 사용자 입력, 시도 횟수  
    char play_again; // 게임을 계속할지 여부  
  
    do {  
        srand(time(0)); // 랜덤 숫자 생성기 초기화  
        number_to_guess = rand() % 100 + 1; // 1부터 100 사이의 랜덤 숫자 생성  
        attempts = 0; // 시도 횟수 초기화  
  
        printf("Guess a number between 1 and 100!\n"); // 게임 시작 메시지  
  
        do {  
            printf("Enter your guess: "); // 사용자 입력 요청  
            scanf("%d", &user_guess); // 사용자 입력 받기  
            attempts++; // 시도 횟수 증가  
  
            if (user_guess < number_to_guess) {  
                printf("It's a bigger number.\n"); // 사용자 입력이 작을 경우  
            } else if (user_guess > number_to_guess) {  
                printf("It's a smaller number.\n"); // 사용자 입력이 클 경우  
            } else {  
                printf("Congratulations! You guessed %d in %d attempts.\n", number_to_guess, attempts); // 정답일 경우  
            }  
        } while (user_guess != number_to_guess); // 정답이 아닐 때까지 반복  
  
        printf("Do you want to play again? (y/n): "); // 게임 계속 여부 입력 요청  
        scanf(" %c", &play_again); // 게임 계속 여부 입력 받기  
    } while (play_again == 'y' || play_again == 'Y'); // 'y' 또는 'Y' 입력 시 계속  
  
    printf("Thanks for playing! Goodbye!\n"); // 게임 종료 메시지  
}  
  
int main() {  
    guess_the_number(); // 게임 시작  
    return 0; // 프로그램 종료  
}  