#include <stdio.h>          // stdio.h: 표준 입출력 기능을 사용
#include <string.h>         // string.h: 문자열 처리 관련 함수 제공

#define TOTAL_STUDENTS 20     //학생 수
#define STUDENTS_NAME 10      //학생 이름 최대길이

int main() {
    // 변수 선언
    FILE *file;
    char name[STUDENTS_NAME];           // 학생 이름을 저장할 배열
    int score = 0;                      // 학생 성적을 저장할 변수
    int sum = 0;                        // 전체 성적의 합
    int top_score = 0;                  // 최고 성적
    char top_score_name[STUDENTS_NAME]; // 최고 성적 학생 이름

    // 학생 정보를 저장할 배열
    char students[TOTAL_STUDENTS][STUDENTS_NAME];  // 학생들의 이름을 저장할 2차원 배열
    int scores[TOTAL_STUDENTS];  // 학생들의 성적을 저장할 배열

    // 파일을 열어 학생 리스트를 불러온다
    file = fopen("grades.txt", "r");
    
// 학생 데이터 읽기
for (int i = 0; i < TOTAL_STUDENTS; i++) {
    fscanf(file, "%s %d", name, &score);
    strcpy(students[i], name);      // 학생 이름 저장
    scores[i] = score;              // 성적 저장
    sum += score;                   // 성적 합산
    
    // 최고 성적 기록
    if (score > top_score) {
        top_score = score;
        strcpy(top_score_name, name);
    }
}
    
    // 파일 닫기
    fclose(file);
    
    // 평균
    double average = sum / (double)TOTAL_STUDENTS;
    printf("1. 전체 학생의 평균점수는 %f점 입니다. \n\n", average);
    
    // 평균 이상 점수 학생 출력
    printf("2. 평균 이상의 점수를 취득한 학생 이름과 성적은 다음과 같습니다. \n\n");
    for (int i = 0; i < TOTAL_STUDENTS; i++) {
        if (scores[i] >= average) {
            printf("%s %d\n", students[i], scores[i]);
        }
    }
    
    // 최고 성적 학생 출력
    printf("\n3. 최고성적의 학생 이름은 %s이며 점수는 %d점 입니다.\n", top_score_name, top_score);
    
    return 0;
}
